# Changelog

All notable changes to this project are documented here. This project adheres to
[Semantic Versioning](https://semver.org/).

## [Unreleased]

- **Re-verified against reference `1.12.0`** — `SPEC_VERSION` is now `"1.12.0"`. The fixture was
  regenerated from the new reference and every number in it is identical to the `1.11.3` one
  (1.12.0 added JS-only blocks outside the fixture); the parity suite passes unchanged. No
  numerical change to this port.

## [0.6.0]

- **`abc()` shipped with its parity to the reference never once measured.** `P_abc` has been in the
  fixture from the start, but the entry carries a `$factory` descriptor instead of a `config` dict
  and this suite only knew how to build from `config` — so the config was silently skipped while the
  suite reported all green. It now runs: `abc()` matches the reference **exactly**, `0.0` difference
  on `u`, `w` and `A` across all eight sample points and on the whole mode table. A coverage hole,
  not a defect — but it was indistinguishable from one until measured.
- **New `SPEC_VERSION`** (`"1.11.3"`) — the revision of the JS reference this port is verified
  against, pinned by `tests/test_parity.py` to the `$spec_version` key now recorded in
  `spec/parity_fixture.json`. Regenerating the fixture from a newer reference fails the suite until
  someone re-verifies the port. `VERSION` keeps its existing meaning (this package's own version);
  the two are now documented as answering different questions.
- **The package docstring claimed to be "numerically at parity with the reference"** without
  qualification, while the sparse-atom engine, the structure primitives and the time warps are not
  ported at all. It now names what is verified (spectral engine, SDF boundary) and points at the
  parity table for the rest.
- **Doc comments were shifted by one item**: `PHI` carried `POLAR_SALT`'s description and
  `POLAR_SALT` carried none. Reattached.
- **Flutter (spec 1.3)**: `flutter` adds a fast, deterministic second harmonic to each mode's phase
  — `ph_eff = ph + flutter*(sin(omf*t + ph) - sin(ph))`, which vanishes exactly at `t = 0` and
  consumes no RNG draws. Rate is the finest scale's eddy rate times PHI, so it never
  resynchronizes with the churn drift. Fixture gains `R_flutter`.

## [0.5.0]

- **Preset bundles**: `exact_ns` (single-shell Beltrami + exact Stokes decay — a true Navier-Stokes
  solution), `ns_developed` / `ns_forced` (measured polarization, inverted exactly; spectrum
  deliberately not calibrated) and `NS_TARGETS`. New `relative_helicity_spectral(t)`: the exact,
  grid-free relative helicity, `2*chi/(1+chi^2)` for a single mode.

## [0.4.0]

- **Grain axis (spec 1.2)**: `polarizationAxis` / `polarizationBias` add world-anchored linear
  polarization — the third channel of the spectral tensor. Off by default (`null` axis), and then
  bit-identical to before; when on, a second independent mulberry32 stream (seed + `POLAR_SALT`)
  supplies 4 draws per mode so the main build's draw order is untouched. Folded frames take the
  general cross-product curl/potential (spec §4b, §5, §8). Fixture gains `Q_grain`.

## [0.3.0]

- **Scale-dependent dials**: `helicity` and `coherence` accept a pure per-wavenumber callable
  (spec §4), consuming no RNG draws — a constant callable reproduces the scalar config
  bit-identically. New presets `shellPeak` / `rolloff` / `condensate` (spec §10.1), the closed-form
  RNG-free `abc()` field (spec §10.2) and the `twoScale` composite (spec §10.3). Fixture gains
  `M_coherence_k`, `N_helicity_k`, `O_shellpeak`, `P_abc`.

## [0.2.0]

- **`ellipticity` (spec 1.1)**: per-mode chirality `chi = ellipticity * s` — `1` (default) keeps the
  circular/Beltrami modes bit-identical, `0` gives linearly-polarized modes (sheets instead of tubes).
  Divergence-freedom and the exact vector potential hold for every value. Parity fixture gains the
  `chi` array plus configs `J_elliptic_linear`, `K_elliptic_half`, `boundary_L_elliptic`.

## [0.1.0] - 2026-07-07

Initial release of the Python port of Helix Noise.

- Spectral, grid-free, divergence-free 3-D velocity field as an analytic sum of Beltrami (helical)
  modes, evaluatable at any point in space and time.
- Three artist controls: spectral slope (size of the swirls), helicity (energy split between +/-
  helical states), and phase coherence (random phases → structured eddies).
- Time evolution via `churn` (advective time-evolution rate) and `decay` (viscous amplitude decay
  `e^(-ν k² t)`).
- Free-slip SDF boundary (`with_boundary` → `BoundedField`): `curl(ramp(d/thickness) · A)` — stays
  divergence-free, tangent to the wall, zero inside the obstacle, and identical to the base field
  beyond the influence band.
- GLSL emitter (`glsl`): self-contained WebGL2 / GLSL ES 3.00 shader with the mode arrays baked in
  as constants; emits the velocity functions, optional `Curl` and `Pot` variants, and compiles the
  decay term in when set.
- numpy vectorized batch sampling: `sample_many` and `sample_many_uw` evaluate many points at once
  and return numpy arrays.
- Numerical parity with the JavaScript reference: the `mulberry32` RNG stream is bit-identical, and
  a fixture-checked parity suite matches mode arrays, samples, relative helicity, bake sums,
  boundary samples, and the GLSL emitter to `1e-9`.
- The atom engine from the JavaScript library is out of scope for this release and is a documented
  follow-up.
