# Changelog

All notable changes to this project are documented here. This project adheres to
[Semantic Versioning](https://semver.org/).

## [Unreleased]

- **Re-verified against reference `1.12.0`** — `SPEC_VERSION` is now `"1.12.0"`. The fixture was
  regenerated from the new reference with every number identical to the `1.11.3` one;
  `tests/test_shaders.py` passes unchanged. No change to any emitted shader.

## [0.5.0]

- **`VERSION` said `1.8.0` in a tool whose CHANGELOG said `0.5.0`.** It mirrored a reference release
  rather than this emitter, so the two version lines in one file disagreed by three minor versions.
  `VERSION` is now this tool's own (`0.5.0`).
- **New `SPEC_VERSION`** (`"1.11.3"`) — the revision of the JS reference the emitter is verified
  against, pinned by `tests/test_shaders.py` to the `$spec_version` key now recorded in
  `spec/parity_fixture.json`, so regenerating the fixture from a newer reference fails the suite
  until someone re-verifies. It says which reference the numbers match, never which blocks are
  ported (`twoScale` still is not — see the parity table in `spec/PORTING_SPEC.md`).
- **Flutter (spec 1.3)**: `flutter` adds a fast, deterministic second harmonic to each mode's phase
  — `ph_eff = ph + flutter*(sin(omf*t + ph) - sin(ph))`, which vanishes exactly at `t = 0` and
  consumes no RNG draws. Rate is the finest scale's eddy rate times PHI, so it never
  resynchronizes with the churn drift. New `--flutter` CLI flag; all four targets
  bake `_FL` / `_OMF[]`.

## [0.4.0]

- **Grain axis (spec 1.2)**: `polarizationAxis` / `polarizationBias` add world-anchored linear
  polarization — the third channel of the spectral tensor. Off by default (`null` axis), and then
  bit-identical to before; when on, a second independent mulberry32 stream (seed + `POLAR_SALT`)
  supplies 4 draws per mode so the main build's draw order is untouched. Folded frames take the
  general cross-product curl/potential (spec §4b, §5, §8). New CLI flags
  `--polarization-axis` and `--polarization-bias`.

## [0.3.0]

- **Scale-dependent dials**: `helicity` and `coherence` accept a pure per-wavenumber callable
  (spec §4), consuming no RNG draws — a constant callable reproduces the scalar config
  bit-identically. New presets `shellPeak` / `rolloff` / `condensate` (spec §10.1), the closed-form
  RNG-free `abc()` field (spec §10.2) and the `twoScale` composite (spec §10.3). New CLI flags
  `--spectrum-preset`, `--coherence-preset`, `--helicity-preset` and `--abc`.

## [0.2.0]

- **`ellipticity` (spec 1.1)**: per-mode chirality `chi = ellipticity * s` — `1` (default) keeps the
  circular/Beltrami modes bit-identical, `0` gives linearly-polarized modes (sheets instead of tubes).
  Divergence-freedom and the exact vector potential hold for every value. New `--ellipticity` CLI flag; all four targets (GLSL/HLSL/WGSL/Godot) emit the general
  two-term curl/potential bodies when `ellipticity != 1`.

## [0.1.0] - 2026-07-07

Initial release of the Helix Noise shader generator — an engine-agnostic port of the
JavaScript reference library that bakes the field into ready-to-paste shader constants.

- Spectral Beltrami-mode engine: an analytic sum of helical modes producing a divergence-free
  3D velocity field, evaluatable at any point.
- Three artist controls: spectral `--slope` (size of the swirls), `--helicity` (handedness of
  the swirl), and phase `--coherence` (calm noise → organized structure).
- Time evolution: `--churn` (evolution rate) and `--decay` (viscous amplitude falloff
  `e^(-NU·k²·t)`) for the `helixNoise(p, t)` entry point.
- Emitted functions: `helixNoise` (velocity), `helixNoiseCurl` (vorticity, on by default,
  omit with `--no-curl`), and `helixNoisePot` (vector potential, with `--potential`). The
  vector potential enables a free-slip SDF boundary — ramp it by a signed distance function
  and take an in-shader curl to keep flow divergence-free while it slides tangent to obstacles.
- Targets: GLSL (GLSL ES 3.00 / WebGL2), HLSL, WGSL, and Godot `.gdshader`, with per-engine
  paste-in instructions for Shadertoy, Unity, Unreal, Godot 4, and WebGPU. WGSL emits separate
  zero-time entry points (`helixNoise0`, `helixNoiseCurl0`, `helixNoisePot0`) since it has no
  overloading.
- Additional generator options: `--modes`, `--seed`, `--kmin` / `--kmax`, `--centers`,
  `--amplitude`, `--tileable` (integer-lattice, exactly 2π-periodic), `--layout`,
  `--anisotropy` / `--axis`, `--name`, and `--precision`.
- Self-contained: Python 3 standard library only. The generator embeds the mulberry32 RNG and
  the field builder, so there is no in-shader RNG — the mode arrays are baked as `const` blocks.
- Numerical parity with the JS reference: the GLSL target reproduces the JS `field.glsl()`
  output, and all targets are fixture-checked (parsed floats and the numeric self-check match
  to `1e-6`).
- Scope: the spectral engine only. The particle/atom advection engine (`createAtoms`) from the
  JS library is out of scope for this release and is a documented follow-up.
