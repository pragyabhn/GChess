import test from "node:test";
import assert from "node:assert";
import {
  create, abc, exactNS, twoScale, axisymmetric, strainedColumn, collapse, dssCollapse,
  anisotropicCollapse, collapsingVortex, blowupScales, heatExteriorSwirl, HeatKernel,
  ridePulses, pulseRings, transfer, nsResidual, nsResidualRms,
} from "../src/index";
import type { FlowField, Vec3 } from "../src/index";

// ---------------------------------------------------------------------------------------------
// Helpers — every check below is against an independent derivation (finite differences of the
// sampler, or a closed form), never against the code path under test.
// ---------------------------------------------------------------------------------------------

function fdDiv(f: FlowField, x: number, y: number, z: number, t: number, h: number): number {
  const a = f.sample(x + h, y, z, t), b = f.sample(x - h, y, z, t);
  const c = f.sample(x, y + h, z, t), d = f.sample(x, y - h, z, t);
  const e = f.sample(x, y, z + h, t), g = f.sample(x, y, z - h, t);
  return (a[0] - b[0] + c[1] - d[1] + e[2] - g[2]) / (2 * h);
}

function fdGrad9(f: FlowField, x: number, y: number, z: number, t: number, h: number): number[] {
  const out: number[] = new Array(9).fill(0);
  for (let m = 0; m < 3; m++) {
    const p: Vec3 = [x, y, z], q: Vec3 = [x, y, z];
    p[m] += h; q[m] -= h;
    const a = f.sample(p[0], p[1], p[2], t), b = f.sample(q[0], q[1], q[2], t);
    for (let n = 0; n < 3; n++) out[3 * m + n] = (a[n] - b[n]) / (2 * h);
  }
  return out;
}

function fdCurl(fn: (x: number, y: number, z: number) => Vec3, x: number, y: number, z: number, h: number): number[] {
  const d = (i: number, ax: 0 | 1 | 2): number => {
    const p: Vec3 = [x, y, z], q: Vec3 = [x, y, z];
    p[ax] += h; q[ax] -= h;
    return (fn(p[0], p[1], p[2])[i] - fn(q[0], q[1], q[2])[i]) / (2 * h);
  };
  return [d(2, 1) - d(1, 2), d(0, 2) - d(2, 0), d(1, 0) - d(0, 1)];
}

const curlOfGrad = (g: ArrayLike<number>): number[] => [g[5] - g[7], g[6] - g[2], g[1] - g[3]];
const maxAbs = (a: ArrayLike<number>): number => { let m = 0; for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i])); return m; };
const maxDiff = (a: ArrayLike<number>, b: ArrayLike<number>): number => { let m = 0; for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i] - b[i])); return m; };

function logSlope(xs: number[], ys: number[]): number {
  const n = xs.length;
  let sx = 0, sy = 0, sxx = 0, sxy = 0;
  for (let i = 0; i < n; i++) {
    const lx = Math.log(xs[i]), ly = Math.log(ys[i]);
    sx += lx; sy += ly; sxx += lx * lx; sxy += lx * ly;
  }
  return (n * sxy - sx * sy) / (n * sxx - sx * sx);
}

/** The full contract at a point: analytic trace zero, FD divergence, FD gradient, FD curl, potential. */
function checkContract(name: string, f: FlowField, pts: Vec3[], t: number, h: number, tol: number): void {
  let live = 0;
  const g: number[] = new Array(9).fill(0);
  for (const [x, y, z] of pts) {
    const u = f.sample(x, y, z, t);
    const um = maxAbs(u);
    if (um === 0) continue;
    live++;
    f.sampleGrad(x, y, z, g, t);
    const gm = maxAbs(g) || 1;
    assert.ok(Math.abs(g[0] + g[4] + g[8]) < 1e-12 * gm, `${name}: tr(∇u) at (${x},${y},${z}) = ${g[0] + g[4] + g[8]}`);
    assert.ok(Math.abs(fdDiv(f, x, y, z, t, h)) < tol * gm, `${name}: FD divergence at (${x},${y},${z}) = ${fdDiv(f, x, y, z, t, h)}`);
    const gf = fdGrad9(f, x, y, z, t, h);
    assert.ok(maxDiff(g, gf) < tol * gm, `${name}: sampleGrad vs FD at (${x},${y},${z}): ${maxDiff(g, gf)} / ${gm}`);
    const w = f.vorticity(x, y, z, t);
    const wf = fdCurl((a, b, c) => f.sample(a, b, c, t), x, y, z, h);
    assert.ok(maxDiff(w, wf) < tol * gm, `${name}: vorticity vs FD curl: ${maxDiff(w, wf)} / ${gm}`);
    const cg = curlOfGrad(g);
    assert.ok(maxDiff(w, cg) < 1e-6 * gm, `${name}: vorticity vs curl(sampleGrad): ${maxDiff(w, cg)}`);
    const uc = fdCurl((a, b, c) => f.potential(a, b, c, t), x, y, z, h);
    assert.ok(maxDiff(u, uc) < tol * (um + gm * h), `${name}: ∇×A vs u: ${maxDiff(u, uc)} / ${um}`);
  }
  assert.ok(live >= Math.min(pts.length, 3), `${name}: the check must not pass vacuously (only ${live} live points)`);
}

// ---------------------------------------------------------------------------------------------
// Chassis: profiles now receive t
// ---------------------------------------------------------------------------------------------

test("chassis: profiles receive t — a stationary profile is unchanged, a reading one animates", () => {
  const still = axisymmetric({ stream: (q, z) => Math.exp(-q) * z, swirl: (q) => Math.exp(-2 * q) });
  const p: Vec3 = [0.4, -0.3, 0.7];
  const u0 = still.sample(...p, 0);
  for (const t of [0.7, 3]) assert.deepEqual(still.sample(...p, t), u0, "a profile that ignores t is stationary, bit for bit");

  const live = axisymmetric({
    stream: (q, z, t = 0) => Math.exp(-q * (1 + t)) * z,
    swirl: (q, _z, t = 0) => Math.exp(-2 * q) * (1 + t),
  });
  assert.ok(maxDiff(live.sample(...p, 0), live.sample(...p, 0.5)) > 1e-3, "a profile that reads t moves");
  for (const t of [0, 0.5, 2]) {
    assert.ok(Math.abs(fdDiv(live, ...p, t, 1e-5)) < 1e-6, `still incompressible at t=${t} (differenced profiles)`);
  }
});

// ---------------------------------------------------------------------------------------------
// collapsingVortex
// ---------------------------------------------------------------------------------------------

const H = 0.1, AEXP = 0.5 + H, DEXP = 0.5 - H;

function corePoints(tau: number): Vec3[] {
  const lr = Math.sqrt(tau), lz = Math.pow(tau, DEXP);
  const pts: Vec3[] = [];
  const rs = [0.3, 0.8, 1.4, 2.2], zs = [0, 0.35, -0.6];
  let i = 0;
  for (const rr of rs) for (const zz of zs) {
    const th = 0.7 * i++;
    pts.push([rr * lr * Math.cos(th), rr * lr * Math.sin(th), zz * lz]);
  }
  pts.push([0.9, 0.2, 0.3]); // the exterior
  return pts;
}

test("collapsing vortex: exactly incompressible at every time, an ordinary point on its axis", () => {
  const v = collapsingVortex({ h: H, T: 1, bias: 0.25 });
  for (const t of [0, 0.5, 0.9, 0.99]) {
    const tau = 1 - t;
    checkContract(`vortex t=${t}`, v, corePoints(tau), t, 1e-4 * Math.sqrt(tau), 2e-5);
    const lz = Math.pow(tau, DEXP);
    const ua = v.sample(0, 0, 0.2 * lz, t);
    assert.ok(Number.isFinite(ua[2]) && Math.abs(ua[0]) < 1e-12 && Math.abs(ua[1]) < 1e-12, "on the axis: finite axial flow, no radial or azimuthal component");
  }
});

test("collapsing vortex: reproduces the paper's scaling laws (§2.1) — measured, not assumed", () => {
  const b = 0.25, amp = 1.3;
  const v = collapsingVortex({ h: H, T: 1, bias: b, amplitude: amp });
  const taus = [1e-2, 1e-3, 1e-4];
  const Xs = 0.5 / (1 + 2 * H); // the mid-plane maximum of √(2X)(1+2X)^(−1−h)
  const uth: number[] = [], gam: number[] = [], ur: number[] = [], en: number[] = [];
  for (const tau of taus) {
    const t = 1 - tau, r = Math.sqrt(2 * Xs * tau);
    const u = v.sample(r, 0, 0, t);           // at θ = 0, ê_φ = +ŷ
    uth.push(Math.abs(u[1])); gam.push(r * Math.abs(u[1]));
    const u2 = v.sample(r, 0, 0.3 * Math.pow(tau, DEXP), t);
    ur.push(Math.abs(u2[0]));
    // u_z on the axis at z = 0 is closed form: 2·amp·b·τ^(−A)
    const uz = v.sample(0, 0, 0, t)[2];
    assert.ok(Math.abs(uz - 2 * amp * b * Math.pow(tau, -AEXP)) < 1e-9 * Math.abs(uz), `axis u_z at τ=${tau}: ${uz}`);
    // core kinetic energy over a box fixed in similarity units
    const Rb = 1.5 * Math.sqrt(2 * tau), Zb = Math.pow(tau, DEXP), n = 24;
    let E = 0;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
      const rr = ((i + 0.5) / n) * Rb, zz = (-1 + (2 * (j + 0.5)) / n) * Zb;
      const w = v.sample(rr, 0, zz, t);
      E += 0.5 * (w[0] * w[0] + w[1] * w[1] + w[2] * w[2]) * rr * (Rb / n) * ((2 * Zb) / n) * 2 * Math.PI;
    }
    en.push(E);
  }
  assert.ok(Math.abs(logSlope(taus, uth) + AEXP) < 2e-3, `sup|u_θ| ∝ τ^(−½−h): slope ${logSlope(taus, uth)}`);
  assert.ok(Math.abs(logSlope(taus, gam) + H) < 2e-3, `sup|Γ| ∝ τ^(−h): slope ${logSlope(taus, gam)}`);
  assert.ok(Math.abs(logSlope(taus, ur) + 0.5) < 1e-2, `|u_r| ∝ τ^(−½): slope ${logSlope(taus, ur)}`);
  assert.ok(Math.abs(logSlope(taus, en) - (0.5 - 3 * H)) < 2e-2, `E_core ∝ τ^(½−3h): slope ${logSlope(taus, en)}`);
  const s = blowupScales({ h: H, T: 1 }, 1 - 1e-3);
  assert.ok(Math.abs(s.aspect - Math.pow(1e-3, -H)) < 1e-12 && Math.abs(s.energyExponent - (0.5 - 3 * H)) < 1e-15, "blowupScales agrees");
});

test("collapsing vortex: the exterior is the exact azimuthal heat solution (4.29)", () => {
  const K = heatExteriorSwirl(H);
  for (const [r, tau] of [[0.7, 0.2], [1.5, 0.05], [2.2, 0.6], [1.0, 1e-3], [3.1, 0.35]] as const) {
    const hr = 1e-2 * r, ht = 1e-2 * tau;
    const Kt = (K(r, tau + ht) - K(r, tau - ht)) / (2 * ht);
    const Kr = (K(r + hr, tau) - K(r - hr, tau)) / (2 * hr);
    const Krr = (K(r + hr, tau) - 2 * K(r, tau) + K(r - hr, tau)) / (hr * hr);
    const lap = Krr + Kr / r - K(r, tau) / (r * r);
    const scale = Math.abs(Krr) + Math.abs(Kr / r) + Math.abs(K(r, tau) / (r * r));
    // ∂_t K = K_rr + K_r/r − K/r² with t = T − τ, i.e. K_τ + (K_rr + K_r/r − K/r²) = 0
    assert.ok(Math.abs(Kt + lap) < 5e-4 * scale, `heat equation at r=${r}, τ=${tau}: ${Kt + lap} vs ${scale}`);
    assert.ok(Kr < 0, "the exterior swirl decreases outward");
  }
  const kern = new HeatKernel(H);
  assert.ok(Math.abs(kern.value(0) - 1) < 1e-12, "H(0) = 1");
  assert.ok(kern.value(0.5) > kern.value(2) && kern.value(2) > kern.value(50), "H decreases");
  // H(Z)·Z^h → 1/Γ(1+h) = 1/0.9513507698… for h = 0.1
  assert.ok(Math.abs(kern.value(1e6) * Math.pow(1e6, H) - 1 / 0.9513507698668732) < 2e-3, "large-Z asymptote");
  assert.ok(Math.abs(kern.asymptote - 1 / 0.9513507698668732) < 1e-9, "Γ(1+h) from the integral itself");
  const k0 = new HeatKernel(0);
  for (const Z of [0, 1, 7, 1e4]) assert.ok(Math.abs(k0.value(Z) - 1) < 1e-12, "h = 0: H ≡ 1");

  // far outside, the vortex IS this exterior, and it does not depend on height
  const v = collapsingVortex({ h: H, T: 1, cutoff: Infinity, amplitude: 0.8 });
  const tau = 0.3, t = 1 - tau;
  const uA = v.sample(3, 0, 0.4, t), uB = v.sample(3, 0, -0.1, t);
  assert.ok(Math.abs(uA[1] - 0.8 * K(3, tau)) < 1e-10 * Math.abs(uA[1]), `vortex swirl vs exact exterior: ${uA[1]} vs ${0.8 * K(3, tau)}`);
  assert.ok(Math.abs(uA[1] - uB[1]) < 1e-12 && Math.abs(uA[0]) < 1e-14 && Math.abs(uA[2]) < 1e-14, "purely azimuthal and z-independent out there");
});

test("collapsing vortex: potential generates the flow, obstacles compose, the mid-plane parity is the paper's", () => {
  const v = collapsingVortex({ h: H, T: 1, bias: 0.25 });
  const t = 0.6, tau = 0.4;
  // potential: exact curl up to the swirl integral's quadrature
  let err = 0, um = 0;
  for (const [x, y, z] of corePoints(tau)) {
    const u = v.sample(x, y, z, t);
    const c = fdCurl((a, b, cc) => v.potential(a, b, cc, t), x, y, z, 1e-4 * Math.sqrt(tau));
    err = Math.max(err, maxDiff(u, c)); um = Math.max(um, maxAbs(u));
  }
  assert.ok(um > 0 && err < 1e-5 * um, `∇×A = u: ${err} / ${um}`);

  // a free-slip sphere in the flow: no flux through its wall
  const c0: Vec3 = [0.45, 0.1, 0.15], R = 0.12;
  const sdf = (x: number, y: number, z: number): number => Math.hypot(x - c0[0], y - c0[1], z - c0[2]) - R;
  const grad = (x: number, y: number, z: number): number[] => {
    const d = Math.hypot(x - c0[0], y - c0[1], z - c0[2]) || 1;
    return [(x - c0[0]) / d, (y - c0[1]) / d, (z - c0[2]) / d];
  };
  const bounded = v.withBoundary(sdf, { thickness: 0.1, gradient: grad });
  let flux = 0, speed = 0;
  for (let i = 0; i < 12; i++) {
    const th = i * 0.6, ph = i * 1.1;
    const n = [Math.sin(th) * Math.cos(ph), Math.sin(th) * Math.sin(ph), Math.cos(th)];
    const u = bounded.sample(c0[0] + R * n[0], c0[1] + R * n[1], c0[2] + R * n[2], t);
    flux = Math.max(flux, Math.abs(u[0] * n[0] + u[1] * n[1] + u[2] * n[2]));
    speed = Math.max(speed, maxAbs(v.sample(c0[0] + 1.3 * R * n[0], c0[1] + 1.3 * R * n[1], c0[2] + 1.3 * R * n[2], t)));
  }
  assert.ok(speed > 0 && flux < 1e-10 * speed, `wall flux ${flux} vs speed ${speed}`);

  // parity: with no bias, inflow from both sides and outflow up AND down (ψ odd in z)
  const sym = collapsingVortex({ h: H, T: 1, bias: 0 });
  const r = 0.5 * Math.sqrt(tau), z = 0.4 * Math.pow(tau, DEXP);
  const up = sym.sample(r, 0, z, t), dn = sym.sample(r, 0, -z, t);
  assert.ok(Math.abs(up[0] - dn[0]) < 1e-13 && Math.abs(up[1] - dn[1]) < 1e-13 && Math.abs(up[2] + dn[2]) < 1e-13, "u_r, u_θ even, u_z odd");
  assert.ok(up[0] < 0 && up[2] > 0 && dn[2] < 0, "inflow, and axial outflow away from the mid-plane on both sides");
  assert.ok(Math.abs(sym.sample(r, 0, 0, t)[2]) < 1e-14, "unbiased: no axial flow on the mid-plane");
  assert.ok(Math.abs(v.sample(r, 0, 0, t)[2]) > 1e-3, "biased: the waist carries axial flow (§2.1)");

  // h = 0 is the isotropic member
  assert.equal(blowupScales({ h: 0 }, 0.5).aspect, 1);
});

// ---------------------------------------------------------------------------------------------
// Anisotropic warps
// ---------------------------------------------------------------------------------------------

const SCATTER: Vec3[] = Array.from({ length: 16 }, (_, i) => [Math.sin(i * 1.7) * 0.5, Math.cos(i * 2.3) * 0.5, Math.sin(i * 0.9) * 0.5]);

test("anisotropicCollapse: h = 0 is collapse; h > 0 stays exactly incompressible with the Piola scaling", () => {
  const base = create({ modes: 16, seed: 5, tileable: true, coherence: 0.3 });
  const T = 1, q = 0.55;
  const iso = collapse(base, { T, q }), an0 = anisotropicCollapse(base, { T, q, h: 0 });
  const g1: number[] = new Array(9).fill(0), g2: number[] = new Array(9).fill(0);
  for (const t of [0.2, 0.7, 0.95]) for (const [x, y, z] of SCATTER) {
    assert.ok(maxDiff(iso.sample(x, y, z, t), an0.sample(x, y, z, t)) < 1e-12, "velocity");
    assert.ok(maxDiff(iso.vorticity(x, y, z, t), an0.vorticity(x, y, z, t)) < 1e-10, "vorticity");
    assert.ok(maxDiff(iso.potential(x, y, z, t), an0.potential(x, y, z, t)) < 1e-12, "potential");
    assert.ok(maxDiff(iso.sampleGrad(x, y, z, g1, t), an0.sampleGrad(x, y, z, g2, t)) < 1e-10, "gradient");
  }

  const h = 0.15;
  const an = anisotropicCollapse(base, { T, q: 0.5, h });
  for (const t of [0.3, 0.8, 0.95]) {
    checkContract(`aniso t=${t}`, an, SCATTER, t, 1e-5, 1e-6);
    const tau = T - t, Lp = Math.pow(tau, 0.5), La = Math.pow(tau, 0.5 - h), A = 0.5 * Math.pow(tau, -0.5);
    for (const [x, y, z] of SCATTER) {
      const u = an.sample(x, y, z, t), U = base.sample(x / Lp, y / Lp, z / La);
      assert.ok(Math.abs(u[0] - A * U[0]) < 1e-12 && Math.abs(u[1] - A * U[1]) < 1e-12, "across the axis: × A");
      assert.ok(Math.abs(u[2] - (A * La) / Lp * U[2]) < 1e-12, "along the axis: × A·L∥/L⊥ = A·τ^(−h)");
    }
  }
  const tilted = anisotropicCollapse(strainedColumn({ strain: 0.4, viscosity: 0.05 }), { T, q: 0.5, h: 0.2, axis: [0.3, 0.4, 0.866] });
  checkContract("aniso tilted", tilted, SCATTER, 0.6, 1e-5, 1e-6);
});

test("dssCollapse with h: the loop closes — transverse ×λ^a, axial ×λ^(a+h), at two-exponent-rescaled coordinates", () => {
  const T = 1, lambda = 2, b = 0.6, a = 0.8, h = 0.12;
  const base = create({ modes: 24, seed: 5, coherence: 0.4, tileable: true, churn: 1 });
  const f = dssCollapse(base, { T, lambda, b, a, h });
  const check = (n: number): number => {
    let err = 0;
    const sp = Math.pow(lambda, -n * b), sa = Math.pow(lambda, -n * (b - h));
    for (const [x, y, z] of SCATTER) {
      const u0 = f.sample(x, y, z, T - 0.3);
      const un = f.sample(x * sp, y * sp, z * sa, T - 0.3 / Math.pow(lambda, n));
      err = Math.max(err, Math.abs(un[0] - Math.pow(lambda, n * a) * u0[0]), Math.abs(un[1] - Math.pow(lambda, n * a) * u0[1]));
      err = Math.max(err, Math.abs(un[2] - Math.pow(lambda, n * (a + h)) * u0[2]));
    }
    return err;
  };
  assert.ok(check(1) < 1e-11, `one period: ${check(1)}`);
  assert.ok(check(2) < 1e-11, `two periods: ${check(2)}`);
  for (const t of [0.2, 0.6, 0.9]) checkContract(`dss-h t=${t}`, f, SCATTER, t, 1e-5, 1e-6);
});

// ---------------------------------------------------------------------------------------------
// transfer
// ---------------------------------------------------------------------------------------------

test("transfer: closed form on a swirl-free strained column measured against itself", () => {
  const a = 0.7, nu = 0.05, r = 0.8, z = 0.3;
  const col = strainedColumn({ strain: a, viscosity: 0.05, circulation: 0 });
  const res = transfer(col, col, { r, z, n: 32 }, { nu });
  // U = (−a x, −a y, 2a z): ∂_jU_i = diag(−a, −a, 2a)
  assert.ok(Math.abs(res.stress.rr - a * a * r * r) < 1e-12, "⟨u_r²⟩ = a²r²");
  assert.ok(Math.abs(res.stress.rTheta) < 1e-12, "no swirl, no angular-momentum flux");
  assert.ok(Math.abs(res.stress.rZ + 2 * a * a * r * z) < 1e-12, "⟨u_r u_z⟩ = −2a²rz");
  assert.ok(Math.abs(res.energy - 0.5 * (a * a * r * r + 4 * a * a * z * z)) < 1e-12, "energy");
  assert.ok(Math.abs(res.exchange - (a ** 3 * r * r - 8 * a ** 3 * z * z)) < 1e-12, "exchange = a³(r² − 8z²)");
  assert.ok(Math.abs(res.dissipation - 6 * nu * a * a) < 1e-12, "dissipation = 6νa²");
  assert.ok(Math.abs(res.growthRate - (res.exchange - res.dissipation) / (2 * res.energy)) < 1e-12);
  assert.equal(res.samples, 32);
  const ann = transfer(col, col, { r: [0.5, 1], z: [-0.2, 0.2], n: 16, nr: 4, nz: 3 }, { nu });
  assert.equal(ann.samples, 16 * 4 * 3);
  assert.ok(Math.abs(ann.stress.rTheta) < 1e-12 && ann.dissipation > 0);
});

// ---------------------------------------------------------------------------------------------
// ridePulses
// ---------------------------------------------------------------------------------------------

test("ridePulses: exactly divergence-free, analytic gradient and vorticity, exact potential; zero outside", () => {
  const base = strainedColumn({ strain: 0.5, viscosity: 0.05, circulation: 1 });
  const layer = ridePulses(base, {
    rings: [
      { r: 1, z: 0, t0: 0, life: 2, p: 6, kr: 3, kz: 2, widthR: 0.3, widthZ: 0.3 },
      { r: 0.8, z: 0.2, t0: 0.2, life: 1.5, p: 5, polarization: [0, 1, 0], amplitude: 0.7 },
    ],
    nu: 0.01,
  });
  const t = 0.7;
  const pts: Vec3[] = [];
  for (let i = 0; i < 8; i++) {
    const th = i * 0.8, rr = [1.05, 0.9, 0.75, 1.15][i % 4], zz = [0.1, -0.05, 0.25, 0.02][i % 4];
    pts.push([rr * Math.cos(th), rr * Math.sin(th), zz]);
  }
  checkContract("pulses", layer, pts, t, 1e-5, 1e-6);
  assert.deepEqual(layer.sample(2.5, 0, 0, t), [0, 0, 0], "outside every ring's support: exactly zero");
  assert.deepEqual(layer.sample(1, 0, 0.1, -0.1), [0, 0, 0], "before birth: zero");
  assert.deepEqual(layer.sample(1, 0, 0.1, 5), [0, 0, 0], "after death: zero");
  assert.deepEqual(layer.sample(0, 0, 0.1, t), [0, 0, 0], "on the axis: zero, the support stays off it");
  assert.equal(layer.rings.length, 2);

  const tilted = ridePulses(strainedColumn({ strain: 0.5, viscosity: 0.05, circulation: 1, axis: [0.3, 0.4, 0.866] }), {
    rings: [{ r: 1, life: 2, p: 6, kr: 2, kz: 1, widthR: 0.35, widthZ: 0.35 }], axis: [0.3, 0.4, 0.866],
  });
  // points on the tilted ring: c + r ê_ρ(θ) with ê_ρ ⟂ axis
  const n: Vec3 = [0.3, 0.4, 0.866], e1: Vec3 = [0.866, 0, -0.3], e2: Vec3 = [n[1] * e1[2] - n[2] * e1[1], n[2] * e1[0] - n[0] * e1[2], n[0] * e1[1] - n[1] * e1[0]];
  // by t = 0.2 the column's inflow has carried the ring from r = 1 to r = 0.9 — sample there
  const tp: Vec3[] = [];
  for (let i = 0; i < 6; i++) {
    const th = i * 1.05, rr = 0.9 + 0.1 * Math.sin(i);
    tp.push([rr * (Math.cos(th) * e1[0] + Math.sin(th) * e2[0]) + 0.05 * n[0], rr * (Math.cos(th) * e1[1] + Math.sin(th) * e2[1]) + 0.05 * n[1], rr * (Math.cos(th) * e1[2] + Math.sin(th) * e2[2]) + 0.05 * n[2]]);
  }
  checkContract("pulses tilted", tilted, tp, 0.2, 1e-5, 1e-6);
});

test("ridePulses: Rayleigh — a centrifugally unstable base amplifies a ring, solid-body rotation cannot", () => {
  // Γ = 3r²e^(−r²/2): dΓ²/dr < 0 for r > √2, so a ring at r = 2 sits in the unstable band
  const unstable = axisymmetric({ swirl: (q) => 3 * Math.exp(-q / 2) });
  const solid = axisymmetric({ swirl: () => 1 });
  // k_r is left to the Orr default: seeded against the tilt, so |k| bottoms out at p/r mid-life
  const ring = { r: 2, z: 0, life: 3, p: 8, kz: 0, widthR: 0.4, widthZ: 0.4, polarization: [1, 0, 0] as Vec3 };
  const lu = ridePulses(unstable, { rings: [ring], nu: 0.001, steps: 256 });
  const ls = ridePulses(solid, { rings: [ring], nu: 0.001, steps: 256 });
  const su = lu.rings[0], ss = ls.rings[0];
  assert.ok(su.growth > 2, `unstable base: growth ${su.growth}`);
  assert.ok(Math.abs(su.peakAt - 0.5) < 0.1, `the peak sits where |k| is smallest, mid-life: ${su.peakAt}`);
  assert.ok(Math.abs(su.kMin - 8 / 2) < 1e-6 && su.kStart > 2 * su.kMin && Math.abs(su.kEnd - su.kStart) < 1e-6,
    `Orr: |k| ${su.kStart} → ${su.kMin} (= p/r) → ${su.kEnd}`);
  assert.ok(su.atDeath < su.growth, "and viscosity has taken some of it back by death");
  assert.ok(ss.growth <= 1 + 1e-9, `solid body: growth ${ss.growth} — |a| can only decay`);
  assert.ok(Math.abs(ss.kEnd - ss.kStart) < 1e-9 && Math.abs(ss.kMin - ss.kStart) < 1e-9, "solid body leaves the pattern rigid (no tilt)");

  // an axial seed with k_z = 0 lies outside the r–θ centrifugal block: no growth, by the physics
  const la = ridePulses(unstable, { rings: [{ ...ring, polarization: [0, 0, 1] }], nu: 0.001, steps: 256 });
  assert.ok(la.rings[0].growth <= 1 + 1e-9, `axial family decoupled at k_z = 0: growth ${la.rings[0].growth}`);

  // grow, then die: with more viscosity the returning tilt lets damping overtake the amplification
  const lv = ridePulses(unstable, { rings: [ring], nu: 0.01, steps: 256 });
  const s = lv.rings[0];
  assert.ok(s.growth > 1.2 && s.peakAt < 0.6 && s.atDeath < 0.5 * s.growth, `grow-then-decay: growth ${s.growth} at ${s.peakAt}, at death ${s.atDeath}`);
  // the envelope reading agrees: zero at birth and death, positive in between
  assert.equal(lv.envelope(0, 0), 0);
  assert.equal(lv.envelope(0, 3), 0);
  assert.ok(lv.envelope(0, 1) > 0);
  // and state() exposes the same integration: gain peaks where growth says, k_θ = p/r, a ⟂ k
  const st = lv.state(0, 3 * s.peakAt);
  assert.ok(Math.abs(st.gain - s.growth) < 1e-6 && Math.abs(st.k[1] - 4) < 1e-12, `state at the peak: gain ${st.gain}`);
  assert.ok(Math.abs(st.k[0] * st.a[0] + st.k[1] * st.a[1] + st.k[2] * st.a[2]) < 1e-9 * Math.hypot(...st.k) * Math.hypot(...st.a), "transversality");
  assert.equal(lv.state(0, 5).window, 0);
  assert.ok(Math.abs(lv.envelope(0, 1) - lv.state(0, 1).window * lv.state(0, 1).gain) < 1e-12, "envelope = window × gain (seed amplitude 1)");

  // the measured exchange agrees in sign with the integrated amplitude: the growing seed draws
  // energy from the base, the decoupled one gives it back
  const region = { r: [1.6, 2.4] as [number, number], z: [-0.4, 0.4] as [number, number], n: 48, nr: 6, nz: 6 };
  const grow = transfer(unstable, lu, region, { t: 0.6, nu: 0.001 });
  const drain = transfer(unstable, la, region, { t: 0.6, nu: 0.001 });
  assert.ok(grow.energy > 0 && grow.exchange > 0, `growing family: exchange ${grow.exchange}`);
  assert.ok(drain.energy > 0 && drain.exchange < 0, `decoupled family: exchange ${drain.exchange}`);
  const rigid = transfer(solid, ls, region, { t: 0.6, nu: 0.001 });
  assert.ok(Math.abs(rigid.exchange) < 1e-12 * rigid.energy, `solid body exchanges nothing: ${rigid.exchange}`);

  // the generator is deterministic and alternates the two families
  const rings = pulseRings({ count: 6, r: [0.5, 1], z: [-0.2, 0.2], t: [0, 1], p: [4, 9], seed: 7 });
  assert.deepEqual(rings, pulseRings({ count: 6, r: [0.5, 1], z: [-0.2, 0.2], t: [0, 1], p: [4, 9], seed: 7 }));
  assert.deepEqual(rings[0].polarization, [0, 0, 1]);
  assert.deepEqual(rings[1].polarization, [0, 1, 0]);
  for (const r of rings) assert.ok(Number.isInteger(r.p) && r.p! >= 4 && r.p! <= 9 && r.r >= 0.5 && r.r <= 1);
});

// ---------------------------------------------------------------------------------------------
// nsResidual
// ---------------------------------------------------------------------------------------------

test("nsResidual: zero on exact solutions, the viscous defect on inviscid ABC, nonzero on a band", () => {
  const ex = create(exactNS({ k0: 2, nu: 0.02 }));
  for (const t of [0, 0.7]) for (const [x, y, z] of SCATTER) {
    const q = nsResidual(ex, x + 1, y + 2, z + 3, { t });
    assert.ok(q.reference > 0 && q.ratio < 1e-12, `exactNS is exact: ratio ${q.ratio}`);
  }
  const viscousABC = abc(1, 1, 1, { decay: 0.3 });
  assert.ok(nsResidual(viscousABC, 0.3, 1.1, 2.2, { t: 0.5 }).ratio < 1e-12, "ABC with its own viscous decay is exact");

  const inviscidABC = abc(1, 0.7, 0.3);
  const nu = 0.1;
  const q = nsResidual(inviscidABC, 0.3, 1.1, 2.2, { nu });
  const w = inviscidABC.vorticity(0.3, 1.1, 2.2);
  // |k| = 1 for every ABC mode, so −νΔω = νω exactly; the advective terms cancel (Beltrami)
  assert.ok(maxDiff(q.curl, [nu * w[0], nu * w[1], nu * w[2]]) < 1e-13, "∇×R = νω on ABC without decay");

  const band = create({ kmin: 1, kmax: 3, modes: 12, tileable: true, seed: 2 });
  const rms = nsResidualRms(band, { nu: 0.05, n: 6 });
  assert.ok(rms.ratio > 0.05 && rms.samples === 216, `a band of shells is not a solution: ratio ${rms.ratio}`);

  assert.throws(() => nsResidual(twoScale(inviscidABC, band) as never, 0, 0, 0), /spectral engine/);
  assert.throws(() => nsResidual(strainedColumn() as never, 0, 0, 0), /spectral engine/);
});

test("nsResidual: every term agrees with finite differences, churn, flutter and decay included", () => {
  const g = create({ modes: 10, seed: 4, churn: 1.3, flutter: 0.4, decay: 0.02, tileable: true, coherence: 0.2 });
  const nu = 0.07, t = 0.9, h = 1e-4;
  for (const [x0, y0, z0] of SCATTER.slice(0, 6)) {
    const x = x0 + 1, y = y0 + 2, z = z0 + 3;
    const q = nsResidual(g, x, y, z, { nu, t });
    const w = (a: number, b: number, c: number, tt = t): Vec3 => g.vorticity(a, b, c, tt);
    const W = w(x, y, z), U = g.sample(x, y, z, t);
    const Wt = [0, 1, 2].map((i) => (w(x, y, z, t + h)[i] - w(x, y, z, t - h)[i]) / (2 * h));
    const GW: number[] = new Array(9).fill(0);
    for (let m = 0; m < 3; m++) {
      const p: Vec3 = [x, y, z], r: Vec3 = [x, y, z];
      p[m] += h; r[m] -= h;
      const a = w(...p), b = w(...r);
      for (let n = 0; n < 3; n++) GW[3 * m + n] = (a[n] - b[n]) / (2 * h);
    }
    const GU = g.sampleGrad(x, y, z, new Array<number>(9).fill(0), t);
    const LW = [0, 0, 0];
    for (let m = 0; m < 3; m++) {
      const p: Vec3 = [x, y, z], r: Vec3 = [x, y, z];
      p[m] += h; r[m] -= h;
      const a = w(...p), b = w(...r);
      for (let n = 0; n < 3; n++) LW[n] += (a[n] - 2 * W[n] + b[n]) / (h * h);
    }
    const want = [0, 1, 2].map((n) => {
      let adv = 0, str = 0;
      for (let m = 0; m < 3; m++) { adv += U[m] * GW[3 * m + n]; str += W[m] * GU[3 * m + n]; }
      return Wt[n] + adv - str - nu * LW[n];
    });
    assert.ok(maxDiff(q.curl, want) < 1e-4 * q.reference, `closed-form ∇×R vs FD: ${maxDiff(q.curl, want)} / ${q.reference}`);
  }
});
