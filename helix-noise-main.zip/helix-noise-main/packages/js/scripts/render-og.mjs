// Renders the Open Graph / Twitter card images for the 1.12 demos into ../assets — in pure Node,
// from the library itself (no browser, no native deps). Run with `node scripts/render-og.mjs`
// after `npm run build`.
import { collapsingVortex, blowupScales, axisymmetric, ridePulses } from "../dist/helix-noise.js";
import zlib from "node:zlib";
import fs from "node:fs";

const OUT = new URL("../assets/", import.meta.url);
fs.mkdirSync(OUT, { recursive: true });
const W = 1200, H = 630;

// ---------- minimal PNG (RGB8) writer ----------
const crcTable = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (buf) => { let c = 0xffffffff; for (let i = 0; i < buf.length; i++) c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
const chunk = (type, data) => { const t = Buffer.from(type, "ascii"), len = Buffer.alloc(4); len.writeUInt32BE(data.length, 0); const cd = Buffer.concat([t, data]), crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(cd), 0); return Buffer.concat([len, cd, crc]); };
function savePNG(name, w, h, rgb) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) { raw[y * (w * 3 + 1)] = 0; Buffer.from(rgb.buffer, rgb.byteOffset + y * w * 3, w * 3).copy(raw, y * (w * 3 + 1) + 1); }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  fs.writeFileSync(new URL(name, OUT), Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk("IHDR", ihdr), chunk("IDAT", zlib.deflateSync(raw, { level: 9 })), chunk("IEND", Buffer.alloc(0))]));
  console.log(`wrote assets/${name}`);
}

const warm = (x) => [255 * Math.min(1, 0.1 + 1.6 * x), 255 * Math.max(0, Math.min(1, 1.9 * x - 0.35)), 255 * Math.max(0, Math.min(1, 2.6 * x - 1.5))];
const diverging = (x) => { const a = Math.min(1, Math.abs(x)); return x >= 0 ? [20 + 235 * a, 20 + 140 * a, 20 + 30 * a] : [20 + 40 * a, 20 + 140 * a, 20 + 235 * a]; };

// ---------- og-blowup.png: the collapsing vortex, meridional slice in the isotropic frame ----------
{
  const T = 1, h = 0.16, t = 0.9;
  const v = collapsingVortex({ h, T, bias: 0.25 });
  const sc = blowupScales({ h, T }, t);
  const Wx = 6 * sc.lr, Wz = Wx * (H / W);
  const nx = 300, nz = Math.round(nx * (H / W));
  const val = new Float32Array(nx * nz); let pk = 0;
  for (let j = 0; j < nz; j++) for (let i = 0; i < nx; i++) {
    const x = -Wx + (2 * Wx * (i + 0.5)) / nx, z = Wz - (2 * Wz * (j + 0.5)) / nz;
    const u = v.sample(x, 0, z, t); const s = Math.hypot(u[0], u[1], u[2]);
    val[j * nx + i] = s; if (s > pk) pk = s;
  }
  const rgb = new Uint8Array(W * H * 3);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const fx = (x / W) * nx, fy = (y / H) * nz, i0 = Math.min(nx - 2, Math.floor(fx)), j0 = Math.min(nz - 2, Math.floor(fy)), tx = fx - i0, ty = fy - j0;
    const a = val[j0 * nx + i0], b = val[j0 * nx + i0 + 1], c = val[(j0 + 1) * nx + i0], d = val[(j0 + 1) * nx + i0 + 1];
    const s = ((a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty) / pk;
    const col = warm(Math.pow(Math.min(1.2, s) / 1.2, 0.75));
    const k = (y * W + x) * 3; rgb[k] = col[0]; rgb[k + 1] = col[1]; rgb[k + 2] = col[2];
  }
  savePNG("og-blowup.png", W, H, rgb);
}

// ---------- og-pulse.png: a ring pulse from above, on the centrifugally unstable swirl ----------
{
  const base = axisymmetric({ swirl: (q) => 3 * Math.exp(-q / 2) });
  const layer = ridePulses(base, { rings: [{ r: 2, z: 0, life: 3, p: 8, kz: 0, widthR: 0.5, widthZ: 0.5, polarization: [1, 0, 0] }], nu: 0.003, steps: 256 });
  const t = 1.5, Wv = 2.9 * (W / H), Hv = 2.9;
  const nx = 400, ny = Math.round(nx * (H / W));
  const val = new Float32Array(nx * ny); let pk = 1e-12;
  for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
    const x = -Wv + (2 * Wv * (i + 0.5)) / nx, y = Hv - (2 * Hv * (j + 0.5)) / ny, r = Math.hypot(x, y) || 1e-9;
    const u = layer.sample(x, y, 0, t); const wr = (u[0] * x + u[1] * y) / r;
    val[j * nx + i] = wr; if (Math.abs(wr) > pk) pk = Math.abs(wr);
  }
  const rgb = new Uint8Array(W * H * 3);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const fx = (x / W) * nx, fy = (y / H) * ny, i0 = Math.min(nx - 2, Math.floor(fx)), j0 = Math.min(ny - 2, Math.floor(fy)), tx = fx - i0, ty = fy - j0;
    const a = val[j0 * nx + i0], b = val[j0 * nx + i0 + 1], c = val[(j0 + 1) * nx + i0], d = val[(j0 + 1) * nx + i0 + 1];
    const s = ((a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty) / pk;
    const col = diverging(s);
    const k = (y * W + x) * 3; rgb[k] = col[0]; rgb[k + 1] = col[1]; rgb[k + 2] = col[2];
  }
  savePNG("og-pulse.png", W, H, rgb);
}
