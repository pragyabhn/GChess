import { HelixField } from "./field";
import type { Field, Vec3 } from "./types";

/**
 * How much external force a field secretly requires.
 *
 * Any divergence-free field solves the Navier–Stokes equations *for some force* — define the force
 * as the residual `R(u,p) = ∂_t u + (u·∇)u − νΔu + ∇p` and the equations hold by construction. That
 * framing is the opening move of the 2026 forced-blowup construction, and turned around it is a
 * meter: a field is "physical" to the extent that its residual is small compared with the terms
 * that make it up.
 *
 * The pressure is removed by taking the curl, which turns the residual into the vorticity
 * equation's defect:
 *
 * ```
 * ∇×R = ∂_t ω + (u·∇)ω − (ω·∇)u − νΔω
 * ```
 *
 * For the spectral engine every term is closed-form — each mode is a plane wave, so `Δω_j = −k²ω_j`,
 * the time derivative comes from the phase rate and the viscous decay, and the two advective terms
 * from the analytic gradients of `u` and `ω`. Nothing is differenced.
 */
export interface ResidualOptions {
  /**
   * Viscosity `ν` in the residual. Defaults to the field's own `decay`, so a field built to decay
   * viscously is judged at the viscosity it was built with (and `exactNS` reads exactly zero).
   */
  nu?: number;
  /** Time. Default 0. */
  t?: number;
}

/** One reading of {@link nsResidual}. */
export interface ResidualSample {
  /** `∇×R` — the curl of the force the field requires, at this point. */
  curl: Vec3;
  /** `|∇×R|`. */
  magnitude: number;
  /** `|∂_t ω| + |(u·∇)ω| + |(ω·∇)u| + ν|Δω|` — the size of the terms that should cancel. */
  reference: number;
  /** `magnitude / reference` ∈ [0, 1]: 0 is an exact solution, near 1 means the terms do not cancel at all. */
  ratio: number;
}

const TAU = 2 * Math.PI;

function requireSpectral(field: Field): HelixField {
  if (!(field instanceof HelixField)) {
    throw new Error("helix-noise: nsResidual is defined for the spectral engine (create/abc/exactNS/twoScale) — every term is closed-form there");
  }
  return field;
}

/**
 * The curl of the Navier–Stokes residual of a spectral field at a point.
 *
 * ```js
 * nsResidual(create(exactNS({ k0: 2, nu: 0.02 })), 0.3, 0.4, 0.5).ratio;   // 0 — an exact solution
 * nsResidual(create(twoScale({ kmin: 1, kmax: 1 }, { kmin: 3, kmax: 3 })), 0.3, 0.4, 0.5).ratio;  // > 0
 * ```
 */
export function nsResidual(field: Field, x: number, y: number, z: number, opts: ResidualOptions = {}): ResidualSample {
  const f = requireSpectral(field);
  const t = opts.t ?? 0;
  const nu = opts.nu ?? f.nu;
  const N = f.N, sc = f._scale, nuDec = f.nu;
  const gen = f._general, fl = f._flutter, omf = f._omf;
  const U = [0, 0, 0], W = [0, 0, 0], Wt = [0, 0, 0], LW = [0, 0, 0];
  const GU = new Array<number>(9).fill(0), GW = new Array<number>(9).fill(0);
  const e1 = [0, 0, 0], e2 = [0, 0, 0], w1 = [0, 0, 0], w2 = [0, 0, 0];
  for (let j = 0; j < N; j++) {
    const kx = f.kx[j], ky = f.ky[j], kz = f.kz[j], km = f.km[j];
    const p0 = f.ph[j];
    let ph = p0, dph = f.om[j];
    if (fl > 0 && omf) {
      ph = p0 + fl * (Math.sin(omf[j] * t + p0) - Math.sin(p0));
      dph += fl * omf[j] * Math.cos(omf[j] * t + p0);
    }
    const phi = kx * x + ky * y + kz * z + ph + f.om[j] * t;
    const c = Math.cos(phi), sn = Math.sin(phi);
    const a = f.a[j] * (nuDec > 0 && t !== 0 ? Math.exp(-nuDec * km * km * t) : 1);
    if (gen) {
      e1[0] = f.e1x[j]; e1[1] = f.e1y[j]; e1[2] = f.e1z[j];
      e2[0] = f.e2x[j]; e2[1] = f.e2y[j]; e2[2] = f.e2z[j];
      w1[0] = f.w1x![j]; w1[1] = f.w1y![j]; w1[2] = f.w1z![j];
      w2[0] = f.w2x![j]; w2[1] = f.w2y![j]; w2[2] = f.w2z![j];
    } else {
      const chi = f.chi[j];
      e1[0] = f.e1x[j]; e1[1] = f.e1y[j]; e1[2] = f.e1z[j];
      e2[0] = chi * f.e2x[j]; e2[1] = chi * f.e2y[j]; e2[2] = chi * f.e2z[j];
      w1[0] = chi * km * f.e1x[j]; w1[1] = chi * km * f.e1y[j]; w1[2] = chi * km * f.e1z[j];
      w2[0] = km * f.e2x[j]; w2[1] = km * f.e2y[j]; w2[2] = km * f.e2z[j];
    }
    const k3 = [kx, ky, kz];
    for (let n = 0; n < 3; n++) {
      const un = a * (c * e1[n] - sn * e2[n]);
      const wn = a * (c * w1[n] - sn * w2[n]);
      U[n] += un; W[n] += wn;
      // ∂_t ω_j = a(−sin φ w1 − cos φ w2)·φ̇ + (ȧ/a) ω_j,   ȧ/a = −ν_decay k²
      Wt[n] += a * (-sn * w1[n] - c * w2[n]) * dph - nuDec * km * km * wn;
      LW[n] += -km * km * wn;
      const du = a * (-sn * e1[n] - c * e2[n]);
      const dw = a * (-sn * w1[n] - c * w2[n]);
      for (let m = 0; m < 3; m++) { GU[3 * m + n] += k3[m] * du; GW[3 * m + n] += k3[m] * dw; }
    }
  }
  for (let i = 0; i < 3; i++) { U[i] *= sc; W[i] *= sc; Wt[i] *= sc; LW[i] *= sc; }
  for (let i = 0; i < 9; i++) { GU[i] *= sc; GW[i] *= sc; }
  const adv = [0, 0, 0], str = [0, 0, 0];
  for (let n = 0; n < 3; n++) for (let m = 0; m < 3; m++) {
    adv[n] += U[m] * GW[3 * m + n]; // (u·∇)ω
    str[n] += W[m] * GU[3 * m + n]; // (ω·∇)u
  }
  const curl: Vec3 = [0, 0, 0];
  for (let n = 0; n < 3; n++) curl[n] = Wt[n] + adv[n] - str[n] - nu * LW[n];
  const magnitude = Math.hypot(curl[0], curl[1], curl[2]);
  const reference =
    Math.hypot(Wt[0], Wt[1], Wt[2]) + Math.hypot(adv[0], adv[1], adv[2]) +
    Math.hypot(str[0], str[1], str[2]) + nu * Math.hypot(LW[0], LW[1], LW[2]);
  return { curl, magnitude, reference, ratio: reference > 0 ? magnitude / reference : 0 };
}

/** One number for the whole field: rms of `|∇×R|` over an `n³` grid on the `2π` cube, and its ratio to the rms reference. */
export function nsResidualRms(field: Field, opts: ResidualOptions & { n?: number } = {}): { rms: number; reference: number; ratio: number; samples: number } {
  const n = Math.max(2, opts.n ?? 8);
  let s = 0, r = 0, count = 0;
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) for (let k = 0; k < n; k++) {
    const q = nsResidual(field, (i / n) * TAU, (j / n) * TAU, (k / n) * TAU, opts);
    s += q.magnitude * q.magnitude; r += q.reference * q.reference; count++;
  }
  const rms = Math.sqrt(s / count), reference = Math.sqrt(r / count);
  return { rms, reference, ratio: reference > 0 ? rms / reference : 0, samples: count };
}
