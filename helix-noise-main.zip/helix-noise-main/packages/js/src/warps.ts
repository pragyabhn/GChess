import { BoundedFieldImpl } from "./boundary";
import { lambda2FromGrad, qFromGrad, stretchFromGrad } from "./diagnostics";
import type {
  Bake2DResult,
  Bake3DResult,
  BoundaryOptions,
  BoundedField,
  FlowField,
  Out6,
  Sdf,
  Vec3,
} from "./types";

/**
 * Time warps: transforms that change how a field behaves in `t` rather than what it contains.
 *
 * `churn` and `flutter` are local in time — they drift and jitter phases. These are global: they
 * make the whole pattern **focus**, shrinking toward a point while speeding up, with the two locked
 * together. Any positive length scale and any amplitude keep the field exactly divergence-free
 * (the chain rule gives `∇·u = (A/L)·(∇·U) = 0`), so a warp can never break the library's one
 * guarantee, whatever you set.
 */

const TAU = 2 * Math.PI;

/** Options for {@link collapse}. */
export interface CollapseOptions {
  /** The instant the collapse completes. Sampling is only defined for `t < T`. Default 1. */
  T?: number;
  /**
   * Space exponent. `0 < q < 1` completes in finite time; as `q → 1` it becomes a gentle drift
   * that never quite arrives. Default 0.6.
   */
  q?: number;
  /** The point everything focuses on. Default `[0, 0, 0]`. */
  center?: Vec3;
  /**
   * Tie the amplitude to the scale (`A = |L′|`), so the flow speeds up exactly as fast as it
   * shrinks and the norms follow `‖u‖∞ = q(T−t)^(q−1)`. Set false to zoom without accelerating.
   * Divergence-freedom holds either way. Default true.
   */
  tieAmplitude?: boolean;
  /**
   * Floor on `T − t`, so an animation that runs past `T` degrades instead of returning `Infinity`.
   * Default `1e-4`.
   */
  minTau?: number;
  /**
   * Freeze the wrapped field's own clock, so the warp supplies *all* the motion. Default true,
   * and for {@link dssCollapse} it is what makes the loop exact: self-similarity says the profile
   * repeats, which it cannot do if the profile is itself churning. Set false to let the wrapped
   * field evolve as well — the collapse still works, but the picture no longer closes on itself.
   */
  freezeProfile?: boolean;
}

/** Options for {@link dssCollapse}. */
export interface DssOptions extends CollapseOptions {
  /** Discrete zoom ratio: the picture repeats every `log λ` of renormalization time. Default 2. */
  lambda?: number;
  /** Space exponent `b`. Default 0.6. */
  b?: number;
  /** Amplitude exponent `a`. Default 0.8. */
  a?: number;
  /** 1-periodic, strictly positive scale modulation. Default `1 + 0.25·cos(2πφ)`. */
  scaleProfile?: (phase01: number) => number;
  /** 1-periodic, strictly positive amplitude modulation. Default `1`. */
  ampProfile?: (phase01: number) => number;
  /**
   * Anisotropy exponent: along `axis` the scale is `τ^(b−h)` instead of `τ^b`, so the picture
   * draws out into a column as it collapses. `0` (default) is the isotropic loop above. The loop
   * still closes exactly — see {@link anisotropicCollapse} for what the receipt becomes.
   */
  h?: number;
  /** The column axis for `h ≠ 0`. Normalized internally. Default `[0, 0, 1]`. */
  axis?: Vec3;
}

/** Options for {@link anisotropicCollapse}. */
export interface AnisotropicCollapseOptions extends CollapseOptions {
  /**
   * Anisotropy exponent `h`. The scale across `axis` is `τ^q`, along it `τ^(q−h)`: with `h > 0` the
   * pattern shrinks faster across than along and becomes an ever more slender column. The
   * construction this comes from uses `q = ½` and `0 < h < 1/100`. Default 0.1.
   */
  h?: number;
  /** The column axis. Normalized internally. Default `[0, 0, 1]`. */
  axis?: Vec3;
}

/**
 * Wrap a field in a **focusing** time warp: the whole pattern shrinks toward `center` like
 * `(T − t)^q` while the flow speeds up like `(T − t)^(q−1)`.
 *
 * ```js
 * const imploding = collapse(create({ modes: 48, tileable: true }), { T: 6, q: 0.55 });
 * ```
 *
 * `q` is the drama knob: near 1 a slow gathering, small a violent snap. The collapse *completes*
 * (rather than asymptoting) exactly when `q < 1`.
 *
 * Two practical notes. Sampling past `T` is clamped by `minTau`, not allowed to diverge. And
 * because the warp samples the wrapped field at `(x − c)/L` with `L → 0`, it walks ever further
 * into that field's far reaches — wrap a `tileable` field or a closed-form primitive if you want
 * the structure to survive deep zooms instead of dissolving into hash.
 */
export function collapse(field: FlowField, opts: CollapseOptions = {}): FlowField {
  const T = opts.T ?? 1;
  const q = opts.q ?? 0.6;
  const tie = opts.tieAmplitude !== false;
  const minTau = opts.minTau ?? 1e-4;
  return new WarpField(
    field,
    opts.center ?? [0, 0, 0],
    (t) => Math.pow(Math.max(T - t, minTau), q),
    (t) => (tie ? q * Math.pow(Math.max(T - t, minTau), q - 1) : 1),
    opts.freezeProfile !== false
  );
}

/**
 * The **log-periodic** version: the same focusing, dressed with a modulation that makes it an
 * *exact loop*.
 *
 * Driving by the renormalization time `s = −log(T − t)`, the scale is `(T−t)^b·Θ(s/log λ)` and the
 * amplitude `(T−t)^(−a)·𝒜(s/log λ)` with `Θ` and `𝒜` 1-periodic. So every time `s` advances by
 * `log λ`, the field is **identical to what it was, up to a rescale** by `λ^(−b)` in space and
 * `λ^a` in amplitude — one rendered period tiles the whole collapse, with no cross-fade and no
 * drift. That is the difference between a Droste zoom that is faked and one that closes.
 *
 * The exponents are free parameters here. A hypothetical Navier–Stokes singularity would have to
 * satisfy `1/2 < b < 1` and `b < a < (1+b)/2`, but that is a *necessary* budget constraint on an
 * object nobody has exhibited — it is offered as a sane starting range, not enforced, and this
 * warp is a kinematic animation law rather than a claim about turbulence.
 */
export function dssCollapse(field: FlowField, opts: DssOptions = {}): FlowField {
  const T = opts.T ?? 1;
  const lambda = Math.max(opts.lambda ?? 2, 1.0000001);
  const b = opts.b ?? 0.6;
  const a = opts.a ?? 0.8;
  const h = opts.h ?? 0;
  const minTau = opts.minTau ?? 1e-4;
  const logL = Math.log(lambda);
  const theta = opts.scaleProfile ?? ((p: number): number => 1 + 0.25 * Math.cos(TAU * p));
  const alpha = opts.ampProfile ?? ((): number => 1);
  const phase = (t: number): number => {
    const s = -Math.log(Math.max(T - t, minTau));
    const p = (s / logL) % 1;
    return p < 0 ? p + 1 : p;
  };
  const L = (t: number): number => Math.pow(Math.max(T - t, minTau), b) * theta(phase(t));
  const A = (t: number): number => Math.pow(Math.max(T - t, minTau), -a) * alpha(phase(t));
  if (h === 0) return new WarpField(field, opts.center ?? [0, 0, 0], L, A, opts.freezeProfile !== false);
  return new AnisoWarpField(
    field,
    opts.center ?? [0, 0, 0],
    opts.axis ?? [0, 0, 1],
    L,
    (t) => Math.pow(Math.max(T - t, minTau), b - h) * theta(phase(t)),
    A,
    opts.freezeProfile !== false
  );
}

/**
 * The **two-exponent** collapse: the pattern shrinks like `τ^q` across `axis` and like `τ^(q−h)`
 * along it, so what was a blob becomes a slender column on its way in — the geometry of the 2026
 * forced-blowup construction, as a warp you can put around *any* field.
 *
 * ```js
 * const column = anisotropicCollapse(create({ modes: 32, tileable: true }), { T: 3, h: 0.15 });
 * ```
 *
 * Incompressibility is exact for any two positive scales, for a reason worth knowing: with
 * `M = diag(L⊥, L⊥, L∥)` in the axis frame, the field `v(x) = M·U(M⁻¹(x − c))` has
 * `∇·v = ∇·U` identically (a Piola transform), whatever `M` is. That `M` in front is not optional
 * — plain `U(M⁻¹x)` is *not* divergence-free once the scales differ — and it is also what sets
 * the component scaling: across the axis the velocity scales like the amplitude `A`, along it like
 * `A·L∥/L⊥ = A·τ^(−h)`. So the axial speed of a wrapped vortex runs ahead of its radial speed by
 * exactly the paper's `τ^(−h)`, while its swirl, being transverse, scales with the radial one.
 * (The construction's own leading field has the swirl scaling with the *axial* speed instead; that
 * separation needs the chassis, which is what {@link collapsingVortex} is for.)
 *
 * The three companions scale as: velocity `A·M/L⊥`, vector potential `A·L⊥·L∥·M⁻¹`, gradient
 * `(A/L⊥)·M⁻¹·∇U·M` — the vorticity is *not* a single rescale of `∇×U` when `L⊥ ≠ L∥` (its
 * components mix), which is why it is derived from the wrapped field's closed-form gradient rather
 * than from its vorticity. `h = 0` reproduces {@link collapse} to the last bit.
 */
export function anisotropicCollapse(field: FlowField, opts: AnisotropicCollapseOptions = {}): FlowField {
  const T = opts.T ?? 1;
  const q = opts.q ?? 0.6;
  const h = opts.h ?? 0.1;
  const tie = opts.tieAmplitude !== false;
  const minTau = opts.minTau ?? 1e-4;
  const tau = (t: number): number => Math.max(T - t, minTau);
  return new AnisoWarpField(
    field,
    opts.center ?? [0, 0, 0],
    opts.axis ?? [0, 0, 1],
    (t) => Math.pow(tau(t), q),
    (t) => Math.pow(tau(t), q - h),
    (t) => (tie ? q * Math.pow(tau(t), q - 1) : 1),
    opts.freezeProfile !== false
  );
}

/**
 * `v(x,t) = (A/L⊥)·M·U(M⁻¹(x−c), t)` with `M = L⊥·I + (L∥ − L⊥)·n̂n̂ᵀ`. Gradient
 * `∇v = (A/L⊥)·M⁻¹·∇U·M` in the library's row-major `∂_m u_n` layout (M is symmetric), vorticity
 * read off the gradient's antisymmetric part, potential `A·L⊥·L∥·M⁻¹·A_U`.
 * @internal
 */
class AnisoWarpField implements FlowField {
  private readonly nx: number; private readonly ny: number; private readonly nz: number;
  private readonly _w6: number[] = [0, 0, 0, 0, 0, 0];
  private readonly _w9: number[] = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  private readonly _g9: number[] = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  private readonly _t6: number[] = [0, 0, 0, 0, 0, 0];
  private readonly _m: number[] = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  private readonly _mi: number[] = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  private readonly _xi: number[] = [0, 0, 0];

  constructor(
    private readonly base: FlowField,
    private readonly c: Vec3,
    axis: Vec3,
    private readonly Lp: (t: number) => number,
    private readonly La: (t: number) => number,
    private readonly A: (t: number) => number,
    private readonly freeze: boolean
  ) {
    const n = Math.hypot(axis[0], axis[1], axis[2]) || 1;
    this.nx = axis[0] / n; this.ny = axis[1] / n; this.nz = axis[2] / n;
  }

  /** Fill M and M⁻¹ (row-major, symmetric) for time t and return the scale pair. */
  private mats(t: number): void {
    const lp = this.Lp(t), la = this.La(t);
    const n = [this.nx, this.ny, this.nz];
    const d = la - lp, di = 1 / la - 1 / lp;
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
      const e = i === j ? 1 : 0;
      this._m[3 * i + j] = lp * e + d * n[i] * n[j];
      this._mi[3 * i + j] = e / lp + di * n[i] * n[j];
    }
  }

  private toXi(x: number, y: number, z: number): void {
    const dx = x - this.c[0], dy = y - this.c[1], dz = z - this.c[2];
    const m = this._mi;
    this._xi[0] = m[0] * dx + m[1] * dy + m[2] * dz;
    this._xi[1] = m[3] * dx + m[4] * dy + m[5] * dz;
    this._xi[2] = m[6] * dx + m[7] * dy + m[8] * dz;
  }

  /** out[o..o+2] = k · (mat · v). */
  private mul(mat: number[], v: ArrayLike<number>, vo: number, k: number, out: Out6, o: number): void {
    const a = v[vo], b = v[vo + 1], c = v[vo + 2];
    out[o] = k * (mat[0] * a + mat[1] * b + mat[2] * c);
    out[o + 1] = k * (mat[3] * a + mat[4] * b + mat[5] * c);
    out[o + 2] = k * (mat[6] * a + mat[7] * b + mat[8] * c);
  }

  /** Gv = k · M⁻¹ · Gu · M into out9 (row-major, ∂_m u_n). */
  private gradv(gu: ArrayLike<number>, k: number, out9: Out6): void {
    const mi = this._mi, m = this._m;
    for (let a = 0; a < 3; a++) for (let b = 0; b < 3; b++) {
      let v = 0;
      for (let l = 0; l < 3; l++) {
        const mil = mi[3 * a + l];
        if (mil === 0) continue;
        for (let kk = 0; kk < 3; kk++) v += mil * gu[3 * l + kk] * m[3 * kk + b];
      }
      out9[3 * a + b] = k * v;
    }
  }

  sampleUW<T extends Out6>(x: number, y: number, z: number, out6: T, t = 0): T {
    this.mats(t);
    this.toXi(x, y, z);
    const tb = this.freeze ? 0 : t;
    const k = this.A(t) / this.Lp(t);
    const xi = this._xi;
    this.base.sampleUW(xi[0], xi[1], xi[2], this._w6, tb);
    this.mul(this._m, this._w6, 0, k, out6, 0);
    this.base.sampleGrad(xi[0], xi[1], xi[2], this._w9, tb);
    const g = this._g9;
    this.gradv(this._w9, k, g);
    // ω = ∇×v from the row-major gradient: ω_x = ∂_y v_z − ∂_z v_y, …
    out6[3] = g[5] - g[7];
    out6[4] = g[6] - g[2];
    out6[5] = g[1] - g[3];
    return out6;
  }

  sampleUA<T extends Out6>(x: number, y: number, z: number, out6: T, t = 0): T {
    this.mats(t);
    this.toXi(x, y, z);
    const tb = this.freeze ? 0 : t;
    const lp = this.Lp(t), la = this.La(t), amp = this.A(t);
    const xi = this._xi;
    this.base.sampleUA(xi[0], xi[1], xi[2], this._w6, tb);
    this.mul(this._m, this._w6, 0, amp / lp, out6, 0);
    // A_v = (A/L⊥)·det(M)·M⁻¹·A_U,   det M = L⊥²·L∥
    this.mul(this._mi, this._w6, 3, amp * lp * la, out6, 3);
    return out6;
  }

  sampleGrad<T extends Out6>(x: number, y: number, z: number, out9: T, t = 0): T {
    if (out9.length < 9) throw new Error("helix-noise: sampleGrad needs 9 floats");
    this.mats(t);
    this.toXi(x, y, z);
    const xi = this._xi;
    this.base.sampleGrad(xi[0], xi[1], xi[2], this._w9, this.freeze ? 0 : t);
    this.gradv(this._w9, this.A(t) / this.Lp(t), out9);
    return out9;
  }

  qCriterion(x: number, y: number, z: number, t = 0): number {
    return qFromGrad(this.sampleGrad(x, y, z, this._g9, t));
  }

  lambda2(x: number, y: number, z: number, t = 0): number {
    return lambda2FromGrad(this.sampleGrad(x, y, z, this._g9, t));
  }

  stretching(x: number, y: number, z: number, t = 0): number {
    this.sampleUW(x, y, z, this._t6, t);
    const wx = this._t6[3], wy = this._t6[4], wz = this._t6[5];
    return stretchFromGrad(this.sampleGrad(x, y, z, this._g9, t), wx, wy, wz);
  }

  sample(x: number, y: number, z: number, t = 0): Vec3 {
    this.sampleUW(x, y, z, this._t6, t);
    return [this._t6[0], this._t6[1], this._t6[2]];
  }

  vorticity(x: number, y: number, z: number, t = 0): Vec3 {
    this.sampleUW(x, y, z, this._t6, t);
    return [this._t6[3], this._t6[4], this._t6[5]];
  }

  helicityDensity(x: number, y: number, z: number, t = 0): number {
    this.sampleUW(x, y, z, this._t6, t);
    return this._t6[0] * this._t6[3] + this._t6[1] * this._t6[4] + this._t6[2] * this._t6[5];
  }

  potential(x: number, y: number, z: number, t = 0): Vec3 {
    this.sampleUA(x, y, z, this._t6, t);
    return [this._t6[3], this._t6[4], this._t6[5]];
  }

  withBoundary(sdf: Sdf, opts?: BoundaryOptions): BoundedField {
    return new BoundedFieldImpl(this, sdf, opts);
  }

  bake3D(n: number, t = 0): Bake3DResult {
    const data = new Float32Array(n * n * n * 4);
    let p = 0;
    for (let z = 0; z < n; z++) for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      this.sampleUW((x / n) * TAU, (y / n) * TAU, (z / n) * TAU, this._t6, t);
      data[p] = this._t6[0]; data[p + 1] = this._t6[1]; data[p + 2] = this._t6[2];
      data[p + 3] = this._t6[0] * this._t6[3] + this._t6[1] * this._t6[4] + this._t6[2] * this._t6[5];
      p += 4;
    }
    return { data, size: n, channels: 4 };
  }

  bakePotential3D(n: number, t = 0): Bake3DResult {
    const data = new Float32Array(n * n * n * 4);
    let p = 0;
    for (let z = 0; z < n; z++) for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const px = (x / n) * TAU, py = (y / n) * TAU, pz = (z / n) * TAU;
      this.sampleUA(px, py, pz, this._t6, t);
      data[p] = this._t6[3]; data[p + 1] = this._t6[4]; data[p + 2] = this._t6[5];
      this.sampleUW(px, py, pz, this._t6, t);
      data[p + 3] = this._t6[0] * this._t6[3] + this._t6[1] * this._t6[4] + this._t6[2] * this._t6[5];
      p += 4;
    }
    return { data, size: n, channels: 4 };
  }

  bake2D(nx: number, ny: number, z = 0, t = 0): Bake2DResult {
    const data = new Float32Array(nx * ny * 4);
    let p = 0;
    for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
      this.sampleUW((i / nx) * TAU, (j / ny) * TAU, z, this._t6, t);
      data[p] = this._t6[0]; data[p + 1] = this._t6[1]; data[p + 2] = this._t6[2];
      data[p + 3] = this._t6[0] * this._t6[3] + this._t6[1] * this._t6[4] + this._t6[2] * this._t6[5];
      p += 4;
    }
    return { data, width: nx, height: ny, channels: 4 };
  }
}

/**
 * `u(x,t) = A(t)·U((x−c)/L(t), t)`. Velocity scales by `A`; vorticity picks up an extra `1/L` from
 * the chain rule, and the vector potential an extra `L`. Getting those two wrong is the only real
 * way to break this, so both are tested.
 * @internal
 */
class WarpField implements FlowField {
  /**
   * Per-instance. A warp inside a warp survives a shared buffer by luck — every write is
   * `out6[i] = k * _w6[i]` at the same index, so aliasing degenerates into an in-place rescale.
   * Put a sum node in between, though, and the luck runs out: `compose` accumulates into the outer
   * warp's buffer across its parts, and an inner warp among those parts overwrites it mid-loop, so
   * `warp(compose(A, warp(B)))` drops A and counts B twice at two different scales.
   */
  private readonly _w6: number[] = [0, 0, 0, 0, 0, 0];
  private readonly _w9: number[] = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  private readonly _g9: number[] = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  private readonly _t6: number[] = [0, 0, 0, 0, 0, 0];

  constructor(
    private readonly base: FlowField,
    private readonly c: Vec3,
    private readonly L: (t: number) => number,
    private readonly A: (t: number) => number,
    /** When true the wrapped field is always sampled at t = 0 — see `freezeProfile`. */
    private readonly freeze: boolean
  ) {}

  sampleUW<T extends Out6>(x: number, y: number, z: number, out6: T, t = 0): T {
    const l = this.L(t), amp = this.A(t);
    this.base.sampleUW((x - this.c[0]) / l, (y - this.c[1]) / l, (z - this.c[2]) / l, this._w6, this.freeze ? 0 : t);
    out6[0] = amp * this._w6[0]; out6[1] = amp * this._w6[1]; out6[2] = amp * this._w6[2];
    const wScale = amp / l;
    out6[3] = wScale * this._w6[3]; out6[4] = wScale * this._w6[4]; out6[5] = wScale * this._w6[5];
    return out6;
  }

  sampleUA<T extends Out6>(x: number, y: number, z: number, out6: T, t = 0): T {
    const l = this.L(t), amp = this.A(t);
    this.base.sampleUA((x - this.c[0]) / l, (y - this.c[1]) / l, (z - this.c[2]) / l, this._w6, this.freeze ? 0 : t);
    out6[0] = amp * this._w6[0]; out6[1] = amp * this._w6[1]; out6[2] = amp * this._w6[2];
    const aScale = amp * l;
    out6[3] = aScale * this._w6[3]; out6[4] = aScale * this._w6[4]; out6[5] = aScale * this._w6[5];
    return out6;
  }

  /**
   * `u = A·U(ξ)` with `ξ = (x−c)/L`, so the chain rule gives `∇u = (A/L)·∇U` — the same `A/L` the
   * vorticity carries, for the same reason. Exact whenever the wrapped field's gradient is.
   */
  sampleGrad<T extends Out6>(x: number, y: number, z: number, out9: T, t = 0): T {
    if (out9.length < 9) throw new Error("helix-noise: sampleGrad needs 9 floats");
    const l = this.L(t), amp = this.A(t), k = amp / l;
    this.base.sampleGrad((x - this.c[0]) / l, (y - this.c[1]) / l, (z - this.c[2]) / l, this._w9,
      this.freeze ? 0 : t);
    for (let i = 0; i < 9; i++) out9[i] = k * this._w9[i];
    return out9;
  }

  qCriterion(x: number, y: number, z: number, t = 0): number {
    return qFromGrad(this.sampleGrad(x, y, z, this._g9, t));
  }

  lambda2(x: number, y: number, z: number, t = 0): number {
    return lambda2FromGrad(this.sampleGrad(x, y, z, this._g9, t));
  }

  stretching(x: number, y: number, z: number, t = 0): number {
    this.sampleUW(x, y, z, this._t6, t);
    return stretchFromGrad(this.sampleGrad(x, y, z, this._g9, t), this._t6[3], this._t6[4], this._t6[5]);
  }

  sample(x: number, y: number, z: number, t = 0): Vec3 {
    this.sampleUW(x, y, z, this._t6, t);
    return [this._t6[0], this._t6[1], this._t6[2]];
  }

  vorticity(x: number, y: number, z: number, t = 0): Vec3 {
    this.sampleUW(x, y, z, this._t6, t);
    return [this._t6[3], this._t6[4], this._t6[5]];
  }

  helicityDensity(x: number, y: number, z: number, t = 0): number {
    this.sampleUW(x, y, z, this._t6, t);
    return this._t6[0] * this._t6[3] + this._t6[1] * this._t6[4] + this._t6[2] * this._t6[5];
  }

  potential(x: number, y: number, z: number, t = 0): Vec3 {
    this.sampleUA(x, y, z, this._t6, t);
    return [this._t6[3], this._t6[4], this._t6[5]];
  }

  withBoundary(sdf: Sdf, opts?: BoundaryOptions): BoundedField {
    return new BoundedFieldImpl(this, sdf, opts);
  }

  bake3D(n: number, t = 0): Bake3DResult {
    const data = new Float32Array(n * n * n * 4);
    let p = 0;
    for (let z = 0; z < n; z++) for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      this.sampleUW((x / n) * TAU, (y / n) * TAU, (z / n) * TAU, this._t6, t);
      data[p] = this._t6[0]; data[p + 1] = this._t6[1]; data[p + 2] = this._t6[2];
      data[p + 3] = this._t6[0] * this._t6[3] + this._t6[1] * this._t6[4] + this._t6[2] * this._t6[5];
      p += 4;
    }
    return { data, size: n, channels: 4 };
  }

  bakePotential3D(n: number, t = 0): Bake3DResult {
    const data = new Float32Array(n * n * n * 4);
    let p = 0;
    for (let z = 0; z < n; z++) for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const px = (x / n) * TAU, py = (y / n) * TAU, pz = (z / n) * TAU;
      this.sampleUA(px, py, pz, this._t6, t);
      data[p] = this._t6[3]; data[p + 1] = this._t6[4]; data[p + 2] = this._t6[5];
      this.sampleUW(px, py, pz, this._t6, t);
      data[p + 3] = this._t6[0] * this._t6[3] + this._t6[1] * this._t6[4] + this._t6[2] * this._t6[5];
      p += 4;
    }
    return { data, size: n, channels: 4 };
  }

  bake2D(nx: number, ny: number, z = 0, t = 0): Bake2DResult {
    const data = new Float32Array(nx * ny * 4);
    let p = 0;
    for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
      this.sampleUW((i / nx) * TAU, (j / ny) * TAU, z, this._t6, t);
      data[p] = this._t6[0]; data[p + 1] = this._t6[1]; data[p + 2] = this._t6[2];
      data[p + 3] = this._t6[0] * this._t6[3] + this._t6[1] * this._t6[4] + this._t6[2] * this._t6[5];
      p += 4;
    }
    return { data, width: nx, height: ny, channels: 4 };
  }
}

