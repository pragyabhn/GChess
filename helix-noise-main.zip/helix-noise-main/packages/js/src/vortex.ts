import { axisymmetric } from "./primitives";
import type { AxiProfile } from "./primitives";
import type { FlowField, Vec3 } from "./types";

/**
 * The **collapsing vortex** — the leading-order flow of the 2026 forced-blowup construction
 * ("Finite time blowup for Navier–Stokes", OpenAI, §§2.1–2.3, §3.1), as an instance of the
 * axisymmetric chassis.
 *
 * Two length scales shrink at different rates as `τ = T − t → 0`: the core radius like `τ^½` and
 * its height like `τ^(½−h)`, so the vortex draws itself out into an ever more slender column while
 * the azimuthal and axial speeds grow like `τ^(−½−h)` and the radial inflow like `τ^(−½)`. The
 * similarity clock `q` solves `q − z²·q^(2h) = τ` (unique, monotone), and the profiles are read in
 * `X = r²/(2q)`, `η = z/q^(½−h)` — which is exactly the chassis's own `r²` convention, so the axis
 * is an ordinary point.
 *
 * What is exact and what is not, stated plainly:
 * - incompressibility is exact (the chassis guarantees it for any profiles);
 * - the exterior swirl is the paper's exact heat solution (4.29) — a purely azimuthal flow that
 *   satisfies `∂_t K = K_rr + K_r/r − K/r²` identically, see {@link heatExteriorSwirl};
 * - the core is the *leading* profile only. It is not a Navier–Stokes solution; in the paper the
 *   momentum residual it leaves in the annulus is what the oscillatory pulses cancel.
 *
 * This is a **geometry**, not a singularity on screen. The paper needs `h < 1/100`, where the
 * anisotropy is asymptotically real but visually invisible (`τ^(−h)` is a factor 1.2 at
 * `τ = 10⁻⁸`); the default `h = 0.1` exaggerates it the way the paper's own Figure 1 does.
 */
export interface CollapsingVortexOptions {
  /** Anisotropy exponent `h ∈ [0, 0.45)`: height shrinks like `τ^(½−h)`, radius like `τ^½`. Default 0.1. */
  h?: number;
  /** The singular time. Sampling is only meaningful for `t < T`. Default 1. */
  T?: number;
  /** Floor on `τ = T − t` so an animation past `T` degrades instead of diverging. Default `1e-4`. */
  minTau?: number;
  /** Overall amplitude (both swirl and meridional flow). Default 1. */
  amplitude?: number;
  /** Relative strength of the inward-spiral / axial-outflow part. `0` leaves a pure swirl. Default 1. */
  meridional?: number;
  /**
   * Axial asymmetry `b`. With exact reflection symmetry in `z` the mid-plane carries no axial
   * transport of angular momentum and no radial shear of the axial velocity — a dead waist. A small
   * upward bias (`u_z ≠ 0` at `z = 0`) is what the paper chooses (§2.1). Default 0.25.
   */
  bias?: number;
  /** Core radius in similarity units: the meridional flow lives in `X ≲ coreX`. Default 1. */
  coreX?: number;
  /**
   * Where the inner profile hands over to the exact heat exterior, in `X`. The blend is
   * `exp(−(X/annulusX)²)` — smooth, never a seam. Default 1.
   */
  annulusX?: number;
  /** Smooth spatial cutoff radius `R`: everything is multiplied by `exp(−(ρ/R)⁴)`. `Infinity` for none. Default 4. */
  cutoff?: number;
  center?: Vec3;
  /** Symmetry axis; normalized internally. Default `[0, 0, 1]`. */
  axis?: Vec3;
}

/**
 * The exterior heat kernel of the construction, equation (4.29):
 *
 * ```
 * H(Z) = Γ(1+h)⁻¹ ∫₀^∞ e^(−v) v^h (1 + Z v)^(−h) dv,     H(0) = 1,   H(Z) ~ Z^(−h)/Γ(1+h)
 * ```
 *
 * `K(r, τ) = r^(−1−2h)·H(4τ/r²)` is then an exact solution of the azimuthal heat equation. The
 * integral is evaluated on `u = log v` by the trapezoid rule: the integrand is analytic in the
 * strip `|Im u| < π/2` (beyond it `e^(−e^u)` stops decaying), so the error is `e^(−π²/Δu)` — below
 * double precision at `Δu = ¼` — and the result is tabulated once in `ζ = log(1+Z)` with cubic
 * Hermite interpolation, so a sample costs an interpolation, not an integral.
 */
export class HeatKernel {
  readonly h: number;
  private readonly F: Float64Array;
  private readonly dF: Float64Array;
  private readonly step: number;
  private readonly n: number;
  private readonly zetaMax: number;
  private readonly invGamma: number;

  constructor(h: number, nodes = 1601, zetaMax = 80) {
    this.h = h;
    this.n = nodes;
    this.zetaMax = zetaMax;
    this.step = zetaMax / (nodes - 1);
    this.F = new Float64Array(nodes);
    this.dF = new Float64Array(nodes);
    const I0 = HeatKernel.integrate(h, 0)[0]; // = Γ(1+h)
    this.invGamma = 1 / I0;
    for (let i = 0; i < nodes; i++) {
      const zeta = i * this.step;
      const Z = Math.expm1(zeta);
      const [I, I1] = HeatKernel.integrate(h, Z);
      const H = I / I0, dH = (-h * I1) / I0;
      const w = Math.exp(h * zeta); // (1+Z)^h
      this.F[i] = w * H;
      // dF/dζ = (1+Z)·d/dZ[(1+Z)^h H] = (1+Z)^h [h H + (1+Z) H′]
      this.dF[i] = w * (h * H + (1 + Z) * dH);
    }
  }

  /** `[∫e^(−v) v^h (1+Zv)^(−h) dv, ∫e^(−v) v^(h+1) (1+Zv)^(−h−1) dv]` on `u = log v`. @internal */
  private static integrate(h: number, Z: number): [number, number] {
    const du = 0.25;
    let I = 0, I1 = 0;
    for (let u = -34; u <= 5; u += du) {
      const v = Math.exp(u);
      const base = Math.exp(-v + (1 + h) * u); // e^(−v) v^h · v  (the dv = v du)
      const g = 1 + Z * v;
      const gh = Math.pow(g, -h);
      I += base * gh;
      I1 += base * v * gh / g;
    }
    return [I * du, I1 * du];
  }

  /** Cubic Hermite read of `F(ζ)` and `F′(ζ)`; beyond the table the `Z^(−h)` asymptote. @internal */
  private read(zeta: number, out: number[]): void {
    if (zeta >= this.zetaMax) {
      out[0] = this.F[this.n - 1];
      out[1] = 0;
      return;
    }
    const s = zeta / this.step;
    let i = Math.floor(s);
    if (i >= this.n - 1) i = this.n - 2;
    const x = s - i, x2 = x * x, x3 = x2 * x;
    const h00 = 2 * x3 - 3 * x2 + 1, h10 = x3 - 2 * x2 + x, h01 = -2 * x3 + 3 * x2, h11 = x3 - x2;
    const d = this.step;
    out[0] = h00 * this.F[i] + h10 * d * this.dF[i] + h01 * this.F[i + 1] + h11 * d * this.dF[i + 1];
    const g00 = 6 * x2 - 6 * x, g10 = 3 * x2 - 4 * x + 1, g01 = -6 * x2 + 6 * x, g11 = 3 * x2 - 2 * x;
    out[1] = (g00 * this.F[i] + g10 * d * this.dF[i] + g01 * this.F[i + 1] + g11 * d * this.dF[i + 1]) / d;
  }

  private readonly _r2 = [0, 0];

  /** `H(Z)`, `Z ≥ 0`. */
  value(Z: number): number {
    const zeta = Math.log1p(Math.max(0, Z));
    this.read(zeta, this._r2);
    return this._r2[0] * Math.exp(-this.h * zeta);
  }

  /** `dH/dZ`, `Z ≥ 0` (negative: the exterior swirl decreases outward). */
  derivative(Z: number): number {
    const Zc = Math.max(0, Z);
    const zeta = Math.log1p(Zc);
    this.read(zeta, this._r2);
    const w = Math.exp(-this.h * zeta); // (1+Z)^(−h)
    const H = this._r2[0] * w;
    // F′ = (1+Z)^h [h H + (1+Z) H′]  ⟹  H′ = (F′ (1+Z)^(−h) − h H) / (1+Z)
    return (this._r2[1] * w - this.h * H) / (1 + Zc);
  }

  /** `1/Γ(1+h)`, the large-`Z` prefactor `H(Z) → Z^(−h)/Γ(1+h)`. */
  get asymptote(): number {
    return this.invGamma;
  }
}

/**
 * The exact **heat exterior** of the collapsing vortex, as a plain function of radius and time
 * to the singularity: the azimuthal velocity
 *
 * ```
 * K(r, τ) = r^(−1−2h) · H(4τ / r²)
 * ```
 *
 * solves `∂_t K = K_rr + K_r/r − K/r²` (with `t = T − τ`) identically, decreases in `r`, and tends
 * to the time-independent profile `r^(−1−2h)` as `τ → 0`. It is the part of {@link collapsingVortex}
 * that *is* a Navier–Stokes solution — the receipt is a test, not a remark.
 */
export function heatExteriorSwirl(h: number): (r: number, tau: number) => number {
  const K = new HeatKernel(h);
  return (r: number, tau: number): number => {
    if (!(r > 0)) return 0;
    return Math.pow(r, -1 - 2 * h) * K.value((4 * tau) / (r * r));
  };
}

/** The similarity clock `q(z, τ)` solving `q − z²q^(2h) = τ`, with `∂_z q`. Cached on `(z, τ)`. @internal */
function makeClock(h: number): (z: number, tau: number, out: number[]) => void {
  const D = 0.5 - h;
  let cz = NaN, ct = NaN, cq = 0, cqz = 0;
  return (z: number, tau: number, out: number[]): void => {
    if (z === cz && tau === ct) { out[0] = cq; out[1] = cqz; return; }
    const z2 = z * z;
    // Start at the paper's `q ≍ τ + |z|^(1/D)`, which lies below the root; F is convex and
    // increasing there, so Newton climbs monotonically and never leaves q > 0.
    let q = tau + Math.pow(Math.abs(z), 1 / D);
    let p = 1;
    for (let i = 0; i < 60; i++) {
      p = h === 0 ? 1 : Math.pow(q, 2 * h);
      const f = q - z2 * p - tau;
      const fp = 1 - (2 * h * z2 * p) / q;
      const dq = f / fp;
      q -= dq;
      if (Math.abs(dq) <= 4e-16 * q) break;
    }
    p = h === 0 ? 1 : Math.pow(q, 2 * h);
    const qz = (2 * z * p) / (1 - (2 * h * z2 * p) / q);
    cz = z; ct = tau; cq = q; cqz = qz;
    out[0] = q; out[1] = qz;
  };
}

/**
 * Build the vortex. Returns an ordinary {@link FlowField} — an `axisymmetric()` chassis whose two
 * profiles read the sampler's time — so obstacles, composition, warps and the gradient diagnostics
 * all apply unchanged. See {@link CollapsingVortexOptions} for the knobs and {@link blowupScales}
 * for the predicted scales at a given time.
 *
 * ```js
 * const v = collapsingVortex({ h: 0.1, T: 2, bias: 0.25 });
 * v.sample(0.05, 0, 0.02, 1.9);   // near the core, close to the singular time
 * ```
 */
export function collapsingVortex(opts: CollapsingVortexOptions = {}): FlowField {
  const h = Math.min(0.45, Math.max(0, opts.h ?? 0.1));
  const T = opts.T ?? 1;
  const minTau = Math.max(opts.minTau ?? 1e-4, 1e-12);
  const amp = opts.amplitude ?? 1;
  const mer = opts.meridional ?? 1;
  const b = opts.bias ?? 0.25;
  const Xc = Math.max(opts.coreX ?? 1, 1e-6);
  const Xe = Math.max(opts.annulusX ?? 1, 1e-6);
  const R = opts.cutoff ?? 4;
  const cutOn = Number.isFinite(R) && R > 0;
  const R2 = cutOn ? R * R : 1;
  const A = 0.5 + h, D = 0.5 - h;
  const clock = makeClock(h);
  const kernel = new HeatKernel(h);
  const cq = [0, 0];
  const tauOf = (t: number): number => Math.max(T - t, minTau);

  /** Swirl profile `Γ/r²` and its `∂_q`, `∂_z` at `(q, z, τ)`, into out[0..2]. */
  const swirlAt = (q: number, z: number, tau: number, out: number[]): void => {
    clock(z, tau, cq);
    const qs = cq[0], qsz = cq[1];
    const X = q / (2 * qs), Xq = 1 / (2 * qs), Xz = (-X * qsz) / qs;
    const qsD = Math.pow(qs, -D);
    const es = z * qsD, esz = qsD - (D * z * qsD * qsz) / qs;
    const G = (1 - es * es) * (1 + b * es);
    const Gp = -2 * es * (1 + b * es) + b * (1 - es * es);
    const W = Math.pow(1 + 2 * X, -1 - h), Wx = (-(1 + h) * 2 * W) / (1 + 2 * X);
    const qsA = Math.pow(qs, -1 - h);
    const M = 1 + 0.6 * G;
    const inner = qsA * W * M;
    const innerQ = qsA * Wx * Xq * M;
    const innerZ = ((-1 - h) * qsz * inner) / qs + qsA * (Wx * Xz * M + W * 0.6 * Gp * esz);

    // hand-over to the exact heat exterior:  blend·inner + (1 − blend)·q^(−1−h) H(4τ/q)
    const Xa = X / Xe;
    const blend = Math.exp(-Xa * Xa);
    const omb = -Math.expm1(-Xa * Xa);
    const dBdX = (-2 * X * blend) / (Xe * Xe);
    const blendQ = dBdX * Xq, blendZ = dBdX * Xz;
    let ext = 0, extQ = 0;
    if (X > 1e-6) {
      const Z = (4 * tau) / q;
      const Hv = kernel.value(Z), Hd = kernel.derivative(Z);
      const qh = Math.pow(q, -1 - h);
      ext = qh * Hv;
      extQ = (qh / q) * (-(1 + h) * Hv - Z * Hd);
    }
    let val = blend * inner + omb * ext;
    let valQ = blendQ * inner + blend * innerQ - blendQ * ext + omb * extQ;
    let valZ = blendZ * inner + blend * innerZ - blendZ * ext;

    if (cutOn) {
      const s = (q + z * z) / R2, c = Math.exp(-s * s);
      const cQ = (-2 * s * c) / R2, cZ = (-4 * z * s * c) / R2;
      valQ = valQ * c + val * cQ;
      valZ = valZ * c + val * cZ;
      val *= c;
    }
    out[0] = amp * val; out[1] = amp * valQ; out[2] = amp * valZ;
  };

  /** Stream profile `P` (ψ = r²P) and its `∂_q`, `∂_z`, into out[0..2]. */
  const streamAt = (q: number, z: number, tau: number, out: number[]): void => {
    clock(z, tau, cq);
    const qs = cq[0], qsz = cq[1];
    const X = q / (2 * qs), Xq = 1 / (2 * qs), Xz = (-X * qsz) / qs;
    const qsD = Math.pow(qs, -D);
    const es = z * qsD, esz = qsD - (D * z * qsD * qsz) / qs;
    const P = Math.exp(-(X * X) / (Xc * Xc)), Px = (-2 * X * P) / (Xc * Xc);
    // χ(η) = (η + b)·e^(−2η²): the odd part is the reflection-symmetric core — inflow from both
    // sides, outflow up and down — and the even part `b` is the paper's bias, u_z ≠ 0 on z = 0.
    const e2 = Math.exp(-2 * es * es);
    const chi = e2 * (es + b), chip = e2 * (1 - 4 * es * (es + b));
    const qsm = Math.pow(qs, -A);
    let val = qsm * P * chi;
    let valQ = qsm * Px * Xq * chi;
    let valZ = (-A * qsz * val) / qs + qsm * (Px * Xz * chi + P * chip * esz);
    if (cutOn) {
      const s = (q + z * z) / R2, c = Math.exp(-s * s);
      const cQ = (-2 * s * c) / R2, cZ = (-4 * z * s * c) / R2;
      valQ = valQ * c + val * cQ;
      valZ = valZ * c + val * cZ;
      val *= c;
    }
    const k = amp * mer;
    out[0] = k * val; out[1] = k * valQ; out[2] = k * valZ;
  };

  // The chassis asks for the value and both partials at the same point in a row; evaluate once.
  const cached = (evalAt: (q: number, z: number, tau: number, out: number[]) => void): AxiProfile => {
    let kq = NaN, kz = NaN, kt = NaN;
    const buf = [0, 0, 0];
    const get = (q: number, z: number, t: number): number[] => {
      if (q !== kq || z !== kz || t !== kt) { evalAt(q, z, tauOf(t), buf); kq = q; kz = z; kt = t; }
      return buf;
    };
    const f = ((q: number, z: number, t = 0): number => get(q, z, t)[0]) as AxiProfile;
    f.dq = (q, z, t = 0) => get(q, z, t)[1];
    f.dz = (q, z, t = 0) => get(q, z, t)[2];
    return f;
  };

  const swirl = cached(swirlAt);
  const stream = mer === 0 ? undefined : cached(streamAt);

  // ∫₀^q Γ/r² dq′ for the vector potential. Composite Simpson on ℓ = log(1 + q′/q_s), which
  // resolves both the core (scale q_s, possibly 1e-4) and the exterior tail (scale q) at once.
  const sbuf = [0, 0, 0];
  const swirlIntegral = (q: number, z: number, t = 0): number => {
    if (!(q > 0)) return 0;
    const tau = tauOf(t);
    clock(z, tau, cq);
    const qs = cq[0];
    const L = Math.log1p(q / qs);
    const N = 96, dl = L / N;
    let s = 0;
    for (let i = 0; i <= N; i++) {
      const l = i * dl, e = Math.exp(l);
      const w = i === 0 || i === N ? 1 : i % 2 ? 4 : 2;
      swirlAt(qs * (e - 1), z, tau, sbuf);
      s += w * sbuf[0] * qs * e;
    }
    return (s * dl) / 3;
  };

  return axisymmetric({ stream, swirl, swirlIntegral, center: opts.center, axis: opts.axis });
}

/** Predicted scales of a {@link collapsingVortex} at time `t` (viscosity one, as in the paper's outline). */
export interface BlowupScales {
  /** Time to the singularity, after the `minTau` clamp. */
  tau: number;
  /** Core radius `√τ`. */
  lr: number;
  /** Core height `τ^(½−h)`. */
  lz: number;
  /** Slenderness `lz/lr = τ^(−h)` — also the angular Reynolds number `Re_θ` at viscosity one. */
  aspect: number;
  /** Peak azimuthal speed on the mid-plane, `amplitude · 1.6 · max_X √(2X)(1+2X)^(−1−h) · τ^(−½−h)`. */
  uTheta: number;
  /** Radial inflow scale `τ^(−½)`, relative to `uTheta` a factor `τ^h` smaller. */
  uR: number;
  /** Total kinetic energy of the core scales like `τ^(½−3h)` — it *vanishes* while the speed diverges. */
  energyExponent: number;
}

/** The scales a {@link collapsingVortex} with these options has at time `t`. */
export function blowupScales(opts: CollapsingVortexOptions = {}, t = 0): BlowupScales {
  const h = Math.min(0.45, Math.max(0, opts.h ?? 0.1));
  const T = opts.T ?? 1;
  const tau = Math.max(T - t, Math.max(opts.minTau ?? 1e-4, 1e-12));
  const amp = opts.amplitude ?? 1;
  const y = 1 / (1 + 2 * h); // argmax of √y (1+y)^(−1−h)
  const gmax = Math.sqrt(y) * Math.pow(1 + y, -1 - h);
  return {
    tau,
    lr: Math.sqrt(tau),
    lz: Math.pow(tau, 0.5 - h),
    aspect: Math.pow(tau, -h),
    uTheta: amp * 1.6 * gmax * Math.pow(tau, -0.5 - h),
    uR: Math.pow(tau, -0.5),
    energyExponent: 0.5 - 3 * h,
  };
}
