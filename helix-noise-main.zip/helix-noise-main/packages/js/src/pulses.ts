import { BaseFlow } from "./primitives";
import { mulberry32 } from "./rng";
import type { FlowField, Out6, Vec3 } from "./types";

/**
 * **Ring pulses that ride a base flow** — the fourth field genre, and the first whose content
 * responds to another field.
 *
 * In the 2026 forced-blowup construction (§2.2, §3.3, §7.1) the missing momentum transport on a
 * collapsing vortex is supplied by oscillatory pulses: rings of short waves, localized in radius,
 * height and time, whose wavevector is tilted by the background shear and whose amplitude grows by
 * extracting energy from that shear until viscous damping, strengthening as the radial wavelength
 * shortens, overtakes it. Grow, then die.
 *
 * Each ring here is one such wave: a windowed potential
 *
 * ```
 * A = W(r − R(t)) · W(z − Z(t)) · win(t) · cos(pθ + k_r(t)(r − R) + k_z(t)(z − Z) + φ) · B(t)
 * ```
 *
 * whose exact curl is the velocity — divergence-free by construction, like everything else in the
 * library. The wavenumbers `(k_r, k_z)` follow the eikonal equation of the axisymmetric base
 * (transport plus tilting by `p·∂(U_θ/r)`), so a rigidly rotating base leaves the pattern rigid;
 * the amplitude follows the local linearized momentum equation *in cylindrical components*, with
 * the two curvature terms that make Rayleigh's centrifugal criterion come out exactly, the pressure
 * eliminated by transversality, and damping `ν|k|²`. Both are integrated once per ring at
 * construction with the base's velocity and analytic gradient **frozen at the ring's reference
 * point** — the same local-parameter approximation the atom engine already makes, and the leading
 * order of the construction's own "freeze the amplitude and phase gradient at a point".
 *
 * What this is not: a stability analysis (the envelope is not advected or strained; only its
 * centre drifts), and not the construction's exact pulse (whose profile, cutoff and correction
 * cycle are proof machinery). It is the genre of those pulses with the physics that gives them
 * their look, exposed as knobs: where a ring sits, its angular wavenumber, its seed polarization,
 * and — measured, not set — how much it grows.
 */
export interface PulseRing {
  /** Ring radius. Must exceed `widthR`, so the support stays off the axis. */
  r: number;
  /** Ring height. Default 0. */
  z?: number;
  /** Birth time. The pulse lives on `[t0, t0 + life]`. Default 0. */
  t0?: number;
  /** Lifetime. Default 1. */
  life?: number;
  /** Angular wavenumber (integer ≥ 1). Default 8. */
  p?: number;
  /**
   * Initial radial wavenumber. When omitted it is seeded **against** the tilt the base's shear will
   * impose, so the radial wavelength first lengthens and only then shortens — the Orr mechanism
   * the construction relies on: amplification dominates at first, viscous damping overtakes later.
   * Pass `0` to start untilted, or any value to choose.
   */
  kr?: number;
  /** Initial axial wavenumber. Default 0. */
  kz?: number;
  /** Radial half-width of the envelope (support `|r − R| < widthR`). Default `0.25·r`. */
  widthR?: number;
  /** Axial half-width. Default `0.25·r`. */
  widthZ?: number;
  /** Seed velocity amplitude. Default 1. */
  amplitude?: number;
  /**
   * Seed polarization as cylindrical components `[a_r, a_θ, a_z]`; projected orthogonal to the
   * initial wavevector. Two families with different polarizations carry different momentum fluxes —
   * that is the construction's "two families". Default `[0, 0, 1]`.
   */
  polarization?: Vec3;
  /** Phase offset. Default 0. */
  phase?: number;
}

/** Options for {@link ridePulses}. */
export interface RidePulsesOptions {
  rings: PulseRing[];
  /** Ring axis; normalized internally. Default `[0, 0, 1]`. */
  axis?: Vec3;
  center?: Vec3;
  /** Viscosity for the pulses' damping `ν|k|²`. Default 0.01. */
  nu?: number;
  /** RK4 steps per ring lifetime. Default 64. */
  steps?: number;
}

/** What the layer knows about one ring after integrating it. */
export interface PulseRingState {
  readonly r: number; readonly z: number; readonly t0: number; readonly life: number; readonly p: number;
  /** Peak of `|a(t)|/|a(0)|` over the lifetime — how much the base's shear amplified the pulse. */
  readonly growth: number;
  /** Time (from birth, as a fraction of `life`) at which the peak occurs. */
  readonly peakAt: number;
  /** `|a(life)|/|a(0)|` — the amplitude at death (before the temporal window). Below `growth` means viscosity won. */
  readonly atDeath: number;
  /** `|k|` at birth, its minimum over the lifetime (where the wave is least damped), and at death. */
  readonly kStart: number; readonly kMin: number; readonly kEnd: number;
}

/** The integrated WKB state of one ring at a time — what {@link PulseField.state} returns. */
export interface PulseState {
  /** Wavevector in cylindrical components `[k_r, k_θ, k_z]` (`k_θ = p/r`). */
  k: Vec3;
  /** Velocity amplitude vector in cylindrical components, before the temporal window. */
  a: Vec3;
  /** `|a|/|a(0)|`. */
  gain: number;
  /** The temporal window `win(t)` ∈ [0, 1]; 0 outside the ring's life. */
  window: number;
  /** Where the ring's centre has drifted to. */
  center: { r: number; z: number };
}

/** The pulse layer: a {@link FlowField} plus what it measured about each ring. */
export interface PulseField extends FlowField {
  readonly rings: readonly PulseRingState[];
  /** The ring's velocity amplitude at time `t` (with its temporal window); 0 outside its life. */
  envelope(i: number, t: number): number;
  /** The full WKB state of ring `i` at time `t` — wavevector, amplitude, gain, window, centre. */
  state(i: number, t: number): PulseState;
}

/** A deterministic generator of rings, for {@link ridePulses}. */
export interface PulseRingsSpec {
  count: number;
  /** Radial range. */
  r: [number, number];
  /** Height range. Default `[0, 0]`. */
  z?: [number, number];
  /** Birth-time range. Default `[0, 0]`. */
  t?: [number, number];
  /** Lifetime, or a range. Default 1. */
  life?: number | [number, number];
  /** Integer angular-wavenumber range. Default `[6, 12]`. */
  p?: [number, number];
  /** Initial radial wavenumber range. Default `[0, 0]`. */
  kr?: [number, number];
  /** Initial axial wavenumber range. Default `[0, 0]`. */
  kz?: [number, number];
  /** Envelope half-width as a fraction of the ring radius. Default 0.25. */
  width?: number;
  /** Seed amplitude. Default 1. */
  amplitude?: number;
  /** Integer seed. Default 1. */
  seed?: number;
}

/**
 * Rings drawn deterministically from a seed, alternating between the two polarization families
 * (`[0, 0, 1]` axial and `[0, 1, 0]` azimuthal).
 */
export function pulseRings(spec: PulseRingsSpec): PulseRing[] {
  const rng = mulberry32((spec.seed ?? 1) >>> 0 || 1);
  const pick = (v: [number, number] | undefined, d: [number, number]): number => {
    const a = v ?? d;
    return a[0] + rng() * (a[1] - a[0]);
  };
  const out: PulseRing[] = [];
  for (let i = 0; i < spec.count; i++) {
    const r = pick(spec.r, [1, 1]);
    const z = pick(spec.z, [0, 0]);
    const t0 = pick(spec.t, [0, 0]);
    const life = typeof spec.life === "number" ? spec.life : pick(spec.life, [1, 1]);
    const pr = spec.p ?? [6, 12];
    const p = Math.max(1, Math.round(pr[0] + rng() * (pr[1] - pr[0])));
    const kr = pick(spec.kr, [0, 0]);
    const kz = pick(spec.kz, [0, 0]);
    const w = (spec.width ?? 0.25) * r;
    out.push({
      r, z, t0, life, p, kr, kz, widthR: w, widthZ: w,
      amplitude: spec.amplitude ?? 1,
      polarization: i % 2 === 0 ? [0, 0, 1] : [0, 1, 0],
      phase: 2 * Math.PI * rng(),
    });
  }
  return out;
}

/** Build the pulse layer on `base`. The result is the layer alone — `compose(base, layer)` to see both. */
export function ridePulses(base: FlowField, opts: RidePulsesOptions): PulseField {
  return new PulseLayer(base, opts);
}

/** `W(u) = (1 − u²)³` on `|u| < 1`, with its first two derivatives. @internal */
function window3(u: number, out: number[]): void {
  const s = 1 - u * u;
  out[0] = s * s * s;
  out[1] = -6 * u * s * s;
  out[2] = s * (30 * u * u - 6);
}

function perp(n: Vec3): Vec3 {
  const ax = Math.abs(n[0]), ay = Math.abs(n[1]), az = Math.abs(n[2]);
  const m: Vec3 = ax < ay ? (ax < az ? [1, 0, 0] : [0, 0, 1]) : ay < az ? [0, 1, 0] : [0, 0, 1];
  const d = m[0] * n[0] + m[1] * n[1] + m[2] * n[2];
  const p: Vec3 = [m[0] - d * n[0], m[1] - d * n[1], m[2] - d * n[2]];
  const l = Math.hypot(p[0], p[1], p[2]) || 1;
  return [p[0] / l, p[1] / l, p[2] / l];
}

/** Per-ring frozen data and the integrated tables. @internal */
interface RingData {
  r0: number; z0: number; t0: number; life: number; p: number; phase: number;
  wr: number; wz: number;
  Ur: number; Uz: number; Om0: number;
  steps: number;
  kr: Float64Array; kz: Float64Array; ar: Float64Array; at: Float64Array; az: Float64Array;
  state: PulseRingState;
}

/** @internal */
class PulseLayer extends BaseFlow implements PulseField {
  private readonly nx: number; private readonly ny: number; private readonly nz: number;
  private readonly e1: Vec3; private readonly e2: Vec3;
  private readonly c: Vec3;
  private readonly data: RingData[] = [];
  readonly rings: PulseRingState[] = [];
  private readonly _fr = [0, 0, 0, 0, 0, 0, 0, 0, 0]; // r, theta, zc, e_rho(3), e_phi(3)
  private readonly _lw = new Array<number>(9).fill(0);
  private readonly _acc = new Array<number>(6).fill(0);
  private readonly _accG = new Array<number>(9).fill(0);
  private readonly _W = [0, 0, 0];
  private readonly _Wz = [0, 0, 0];
  private readonly _kb = [0, 0, 0, 0, 0];

  constructor(base: FlowField, opts: RidePulsesOptions) {
    super();
    const ax = opts.axis ?? [0, 0, 1];
    const an = Math.hypot(ax[0], ax[1], ax[2]) || 1;
    this.nx = ax[0] / an; this.ny = ax[1] / an; this.nz = ax[2] / an;
    const n: Vec3 = [this.nx, this.ny, this.nz];
    this.e1 = perp(n);
    this.e2 = [n[1] * this.e1[2] - n[2] * this.e1[1], n[2] * this.e1[0] - n[0] * this.e1[2], n[0] * this.e1[1] - n[1] * this.e1[0]];
    this.c = opts.center ?? [0, 0, 0];
    const nu = Math.max(0, opts.nu ?? 0.01);
    const steps = Math.max(4, (opts.steps ?? 64) | 0);
    for (const ring of opts.rings) this.data.push(this.integrate(base, ring, nu, steps));
    for (const d of this.data) this.rings.push(d.state);
  }

  /** Freeze the base at the ring's reference point and integrate the WKB state with RK4. */
  private integrate(base: FlowField, ring: PulseRing, nu: number, steps: number): RingData {
    const r0 = Math.max(ring.r, 1e-9);
    const z0 = ring.z ?? 0, t0 = ring.t0 ?? 0, life = Math.max(ring.life ?? 1, 1e-9);
    const p = Math.max(1, Math.round(ring.p ?? 8));
    const wr = Math.min(ring.widthR ?? 0.25 * r0, 0.95 * r0), wz = ring.widthZ ?? 0.25 * r0;
    const E: number[][] = [this.e1, this.e2, [this.nx, this.ny, this.nz]];
    const X0 = [this.c[0] + r0 * this.e1[0] + z0 * this.nx, this.c[1] + r0 * this.e1[1] + z0 * this.ny, this.c[2] + r0 * this.e1[2] + z0 * this.nz];
    const U = base.sample(X0[0], X0[1], X0[2], t0);
    const G = base.sampleGrad(X0[0], X0[1], X0[2], new Array<number>(9).fill(0), t0);
    const Ur = U[0] * E[0][0] + U[1] * E[0][1] + U[2] * E[0][2];
    const Ut = U[0] * E[1][0] + U[1] * E[1][1] + U[2] * E[1][2];
    const Uz = U[0] * E[2][0] + U[1] * E[2][1] + U[2] * E[2][2];
    // L[m][n] = ∂_{e_m}(U·e_n): the base gradient in the ring frame (world is Eᵀ L E, so L = E G Eᵀ).
    const L: number[][] = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
    for (let m = 0; m < 3; m++) for (let k = 0; k < 3; k++) {
      let v = 0;
      for (let a = 0; a < 3; a++) for (let b = 0; b < 3; b++) v += E[m][a] * G[3 * a + b] * E[k][b];
      L[m][k] = v;
    }
    const Om0 = Ut / r0;
    const dOmr = L[0][1] / r0 - Ut / (r0 * r0), dOmz = L[2][1] / r0;
    // Linearized momentum in cylindrical components, N[i][j]: (w·∇U + curvature)_i = Σ_j N[i][j] w_j
    const N: number[][] = [
      [L[0][0], (-2 * Ut) / r0, L[2][0]],
      [L[0][1] + Ut / r0, Ur / r0, L[2][1]],
      [L[0][2], 0, L[2][2]],
    ];
    const kth = p / r0;
    // state y = [kr, kz, ar, at, az]
    const rhs = (y: number[], out: number[]): void => {
      const kr = y[0], kz = y[1], a = [y[2], y[3], y[4]];
      const kdr = -(L[0][0] * kr + L[0][2] * kz) - p * dOmr;
      const kdz = -(L[2][0] * kr + L[2][2] * kz) - p * dOmz;
      const xi = [kr, kth, kz], xid = [kdr, 0, kdz];
      const k2 = kr * kr + kth * kth + kz * kz;
      const Na = [0, 0, 0];
      for (let i = 0; i < 3; i++) Na[i] = N[i][0] * a[0] + N[i][1] * a[1] + N[i][2] * a[2];
      // pressure from ξ·a = 0 along the way:  π̂ = (ξ̇·a − ξ·Na)/|ξ|²,   ȧ = −Na − ξ π̂ − ν|ξ|² a
      let xiNa = 0, xida = 0;
      for (let i = 0; i < 3; i++) { xiNa += xi[i] * Na[i]; xida += xid[i] * a[i]; }
      const pi = (xida - xiNa) / k2;
      out[0] = kdr; out[1] = kdz;
      for (let i = 0; i < 3; i++) out[2 + i] = -Na[i] - xi[i] * pi - nu * k2 * a[i];
    };
    // seed wavevector: against the tilt by default (Orr), so |k| passes its minimum mid-life
    const kz0 = ring.kz ?? 0;
    const tiltRate = -(L[0][2] * kz0) - p * dOmr; // k̇_r at k_r = 0
    const kr0 = ring.kr ?? -0.5 * life * tiltRate;
    // seed amplitude: the requested polarization, projected orthogonal to ξ(0)
    const pol = ring.polarization ?? [0, 0, 1];
    const xi0 = [kr0, kth, kz0], k20 = kr0 * kr0 + kth * kth + kz0 * kz0;
    const dot = (pol[0] * xi0[0] + pol[1] * xi0[1] + pol[2] * xi0[2]) / k20;
    let a0 = [pol[0] - dot * xi0[0], pol[1] - dot * xi0[1], pol[2] - dot * xi0[2]];
    let a0n = Math.hypot(a0[0], a0[1], a0[2]);
    if (a0n < 1e-12) { // polarization parallel to the wavevector: pick any transverse direction
      a0 = [-xi0[1], xi0[0], 0]; a0n = Math.hypot(a0[0], a0[1], a0[2]);
      if (a0n < 1e-12) { a0 = [0, -xi0[2], xi0[1]]; a0n = Math.hypot(a0[0], a0[1], a0[2]); }
    }
    const amp = ring.amplitude ?? 1;
    const y = [kr0, kz0, (amp * a0[0]) / a0n, (amp * a0[1]) / a0n, (amp * a0[2]) / a0n];
    const kr = new Float64Array(steps + 1), kz = new Float64Array(steps + 1);
    const ar = new Float64Array(steps + 1), at = new Float64Array(steps + 1), az = new Float64Array(steps + 1);
    const dt = life / steps;
    const k1 = [0, 0, 0, 0, 0], k2 = [0, 0, 0, 0, 0], k3 = [0, 0, 0, 0, 0], k4 = [0, 0, 0, 0, 0], tmp = [0, 0, 0, 0, 0];
    let growth = 1, peakAt = 0, kMin = Infinity;
    for (let s = 0; s <= steps; s++) {
      kr[s] = y[0]; kz[s] = y[1]; ar[s] = y[2]; at[s] = y[3]; az[s] = y[4];
      const mag = Math.hypot(y[2], y[3], y[4]) / amp;
      if (mag > growth) { growth = mag; peakAt = s / steps; }
      kMin = Math.min(kMin, Math.hypot(y[0], kth, y[1]));
      if (s === steps) break;
      rhs(y, k1);
      for (let i = 0; i < 5; i++) tmp[i] = y[i] + 0.5 * dt * k1[i];
      rhs(tmp, k2);
      for (let i = 0; i < 5; i++) tmp[i] = y[i] + 0.5 * dt * k2[i];
      rhs(tmp, k3);
      for (let i = 0; i < 5; i++) tmp[i] = y[i] + dt * k3[i];
      rhs(tmp, k4);
      for (let i = 0; i < 5; i++) y[i] += (dt / 6) * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]);
      // keep ξ·a = 0 exactly against RK4 rounding
      const xi = [y[0], kth, y[1]];
      const kk = xi[0] * xi[0] + xi[1] * xi[1] + xi[2] * xi[2];
      const d = (y[2] * xi[0] + y[3] * xi[1] + y[4] * xi[2]) / kk;
      y[2] -= d * xi[0]; y[3] -= d * xi[1]; y[4] -= d * xi[2];
    }
    const state: PulseRingState = {
      r: r0, z: z0, t0, life, p, growth, peakAt,
      atDeath: Math.hypot(ar[steps], at[steps], az[steps]) / amp,
      kStart: Math.sqrt(k20),
      kMin,
      kEnd: Math.hypot(kr[steps], kth, kz[steps]),
    };
    return { r0, z0, t0, life, p, phase: ring.phase ?? 0, wr, wz, Ur, Uz, Om0, steps, kr, kz, ar, at, az, state };
  }

  /** Interpolated `[kr, kz, ar, at, az]` at `tt = t − t0`, and the temporal window; false if dead. */
  private stateAt(d: RingData, tt: number, out: number[]): number {
    if (!(tt > 0 && tt < d.life)) return 0;
    const s = (tt / d.life) * d.steps;
    let i = Math.floor(s);
    if (i >= d.steps) i = d.steps - 1;
    const f = s - i, g = 1 - f;
    out[0] = g * d.kr[i] + f * d.kr[i + 1];
    out[1] = g * d.kz[i] + f * d.kz[i + 1];
    out[2] = g * d.ar[i] + f * d.ar[i + 1];
    out[3] = g * d.at[i] + f * d.at[i + 1];
    out[4] = g * d.az[i] + f * d.az[i + 1];
    const u = (2 * tt) / d.life - 1, q = 1 - u * u;
    return q * q * q;
  }

  envelope(i: number, t: number): number {
    const d = this.data[i];
    if (!d) return 0;
    const win = this.stateAt(d, t - d.t0, this._kb);
    return win * Math.hypot(this._kb[2], this._kb[3], this._kb[4]);
  }

  state(i: number, t: number): PulseState {
    const d = this.data[i];
    if (!d) throw new Error(`helix-noise: no ring ${i}`);
    const tt = t - d.t0;
    const kb = [0, 0, 0, 0, 0];
    // outside the life, report the nearest endpoint's state with a zero window
    const tc = Math.min(Math.max(tt, 0), d.life);
    const s = (tc / d.life) * d.steps, i0 = Math.min(Math.floor(s), d.steps - 1), f = s - i0, g = 1 - f;
    kb[0] = g * d.kr[i0] + f * d.kr[i0 + 1]; kb[1] = g * d.kz[i0] + f * d.kz[i0 + 1];
    kb[2] = g * d.ar[i0] + f * d.ar[i0 + 1]; kb[3] = g * d.at[i0] + f * d.at[i0 + 1]; kb[4] = g * d.az[i0] + f * d.az[i0 + 1];
    const win = tt > 0 && tt < d.life ? (1 - ((2 * tt) / d.life - 1) ** 2) ** 3 : 0;
    const a0 = Math.hypot(d.ar[0], d.at[0], d.az[0]) || 1;
    return {
      k: [kb[0], d.p / d.r0, kb[1]],
      a: [kb[2], kb[3], kb[4]],
      gain: Math.hypot(kb[2], kb[3], kb[4]) / a0,
      window: win,
      center: { r: d.r0 + d.Ur * tc, z: d.z0 + d.Uz * tc },
    };
  }

  /** Cylindrical frame of a point: r, θ, z and the unit vectors. Returns false on the axis. */
  private frame(x: number, y: number, z: number): boolean {
    const dx = x - this.c[0], dy = y - this.c[1], dz = z - this.c[2];
    const zc = dx * this.nx + dy * this.ny + dz * this.nz;
    const rx = dx - zc * this.nx, ry = dy - zc * this.ny, rz = dz - zc * this.nz;
    const r = Math.hypot(rx, ry, rz);
    if (r < 1e-12) return false;
    const fr = this._fr;
    fr[0] = r; fr[2] = zc;
    fr[3] = rx / r; fr[4] = ry / r; fr[5] = rz / r;
    fr[6] = this.ny * fr[5] - this.nz * fr[4];
    fr[7] = this.nz * fr[3] - this.nx * fr[5];
    fr[8] = this.nx * fr[4] - this.ny * fr[3];
    fr[1] = Math.atan2(dx * this.e2[0] + dy * this.e2[1] + dz * this.e2[2], dx * this.e1[0] + dy * this.e1[1] + dz * this.e1[2]);
    return true;
  }

  /**
   * Accumulate, over the live rings, the cylindrical velocity (acc[0..2]) and either the local
   * gradient rows (want === "grad", into accG) or the potential (want === "pot", into acc[3..5]).
   */
  private evalCyl(r: number, th: number, zc: number, t: number, want: "grad" | "pot"): void {
    const acc = this._acc, accG = this._accG;
    for (let i = 0; i < 6; i++) acc[i] = 0;
    for (let i = 0; i < 9; i++) accG[i] = 0;
    const kb = this._kb, W = this._W, Wz = this._Wz;
    for (const d of this.data) {
      const tt = t - d.t0;
      if (!(tt > 0 && tt < d.life)) continue;
      const R = d.r0 + d.Ur * tt, Z = d.z0 + d.Uz * tt;
      const ur = (r - R) / d.wr, uz = (zc - Z) / d.wz;
      if (ur <= -1 || ur >= 1 || uz <= -1 || uz >= 1) continue;
      const win = this.stateAt(d, tt, kb);
      const kr = kb[0], kz = kb[1];
      const ar = kb[2], at = kb[3], az = kb[4];
      const kth = d.p / d.r0;
      const k2 = kr * kr + kth * kth + kz * kz;
      // potential direction B = a × ξ / |ξ|², so that −env·sin Φ·(ξ × B) = env·sin Φ·… reproduces a
      const Br = (at * kz - az * kth) / k2, Bt = (az * kr - ar * kz) / k2, Bz = (ar * kth - at * kr) / k2;
      window3(ur, W); window3(uz, Wz);
      const env = win * W[0] * Wz[0];
      const envR = (win * W[1] * Wz[0]) / d.wr, envZ = (win * W[0] * Wz[1]) / d.wz;
      const envRR = (win * W[2] * Wz[0]) / (d.wr * d.wr), envZZ = (win * W[0] * Wz[2]) / (d.wz * d.wz);
      const envRZ = (win * W[1] * Wz[1]) / (d.wr * d.wz);
      const p = d.p;
      const Phi = p * th + kr * (r - R) + kz * (zc - Z) + d.phase - p * d.Om0 * tt;
      const cP = Math.cos(Phi), sP = Math.sin(Phi);
      const f = env * cP;
      const fr = envR * cP - env * sP * kr;
      const ft = -env * sP * p;
      const fz = envZ * cP - env * sP * kz;
      if (want === "pot") {
        acc[3] += f * Br; acc[4] += f * Bt; acc[5] += f * Bz;
      }
      // w = ∇×(f B) in cylindrical components
      const ftr = ft / r;
      acc[0] += ftr * Bz - fz * Bt;
      acc[1] += fz * Br - fr * Bz;
      acc[2] += (f / r + fr) * Bt - ftr * Br;
      if (want !== "grad") continue;
      const frr = envRR * cP - 2 * envR * sP * kr - env * cP * kr * kr;
      const frt = -envR * sP * p - env * cP * p * kr;
      const frz = envRZ * cP - envR * sP * kz - envZ * sP * kr - env * cP * kr * kz;
      const ftt = -env * cP * p * p;
      const ftz = -envZ * sP * p - env * cP * p * kz;
      const fzz = envZZ * cP - 2 * envZ * sP * kz - env * cP * kz * kz;
      const r2 = r * r;
      // raw partials ∂_r, ∂_θ, ∂_z of (w_r, w_θ, w_z)
      const wr_r = (frt / r - ft / r2) * Bz - frz * Bt;
      const wr_t = (ftt / r) * Bz - ftz * Bt;
      const wr_z = (ftz / r) * Bz - fzz * Bt;
      const wt_r = frz * Br - frr * Bz;
      const wt_t = ftz * Br - frt * Bz;
      const wt_z = fzz * Br - frz * Bz;
      const wz_r = (fr / r - f / r2 + frr) * Bt - (frt / r - ft / r2) * Br;
      const wz_t = (ft / r + frt) * Bt - (ftt / r) * Br;
      const wz_z = (fz / r + frz) * Bt - (ftz / r) * Br;
      const wr = ftr * Bz - fz * Bt, wt = fz * Br - fr * Bz;
      // gradient rows in the local frame: L[m][n] = e_m·∇(w·e_n), with the frame-rotation terms
      accG[0] += wr_r; accG[1] += wt_r; accG[2] += wz_r;
      accG[3] += (wr_t - wt) / r; accG[4] += (wt_t + wr) / r; accG[5] += wz_t / r;
      accG[6] += wr_z; accG[7] += wt_z; accG[8] += wz_z;
    }
  }

  private world(vr: number, vt: number, vz: number, out: Out6, o: number): void {
    const fr = this._fr;
    out[o] = vr * fr[3] + vt * fr[6] + vz * this.nx;
    out[o + 1] = vr * fr[4] + vt * fr[7] + vz * this.ny;
    out[o + 2] = vr * fr[5] + vt * fr[8] + vz * this.nz;
  }

  sampleUW<T extends Out6>(x: number, y: number, z: number, out6: T, t = 0): T {
    for (let i = 0; i < 6; i++) out6[i] = 0;
    if (!this.frame(x, y, z)) return out6;
    const fr = this._fr;
    this.evalCyl(fr[0], fr[1], fr[2], t, "grad");
    const acc = this._acc, g = this._accG;
    this.world(acc[0], acc[1], acc[2], out6, 0);
    // ω = antisymmetric part of the local gradient: ω_i = ε_ijk L[j][k]
    this.world(g[5] - g[7], g[6] - g[2], g[1] - g[3], out6, 3);
    return out6;
  }

  sampleUA<T extends Out6>(x: number, y: number, z: number, out6: T, t = 0): T {
    for (let i = 0; i < 6; i++) out6[i] = 0;
    if (!this.frame(x, y, z)) return out6;
    const fr = this._fr;
    this.evalCyl(fr[0], fr[1], fr[2], t, "pot");
    const acc = this._acc;
    this.world(acc[0], acc[1], acc[2], out6, 0);
    this.world(acc[3], acc[4], acc[5], out6, 3);
    return out6;
  }

  sampleGrad<T extends Out6>(x: number, y: number, z: number, out9: T, t = 0): T {
    if (out9.length < 9) throw new Error("helix-noise: sampleGrad needs 9 floats");
    for (let i = 0; i < 9; i++) out9[i] = 0;
    if (!this.frame(x, y, z)) return out9;
    const fr = this._fr;
    this.evalCyl(fr[0], fr[1], fr[2], t, "grad");
    const L = this._accG;
    // world = Eᵀ L E, rows of E = [e_ρ, e_φ, n]
    const E = this._lw;
    E[0] = fr[3]; E[1] = fr[4]; E[2] = fr[5];
    E[3] = fr[6]; E[4] = fr[7]; E[5] = fr[8];
    E[6] = this.nx; E[7] = this.ny; E[8] = this.nz;
    for (let m = 0; m < 3; m++) for (let n = 0; n < 3; n++) {
      let v = 0;
      for (let a = 0; a < 3; a++) {
        const eam = E[3 * a + m];
        if (eam === 0) continue;
        for (let b = 0; b < 3; b++) v += eam * L[3 * a + b] * E[3 * b + n];
      }
      out9[3 * m + n] = v;
    }
    return out9;
  }
}
