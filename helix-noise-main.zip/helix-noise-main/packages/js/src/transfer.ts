import type { FlowField, Vec3 } from "./types";

/**
 * Momentum transfer between a base flow and a layer riding on it — the question "does this
 * detail feed the vortex or parasitize it?", answered with the two numbers the 2026 forced-blowup
 * construction is built on.
 *
 * For a perturbation `w` on a background `U` the linearized energy budget is
 *
 * ```
 * d/dt ½∫|w|² = −∫ w_i w_j ∂_j U_i  −  ν∫|∇w|²
 *                 └── exchange ──┘     └ dissipation ┘
 * ```
 *
 * The first term moves energy between the background and the layer (positive: the layer draws on
 * the background's shear); the second only removes it. The same quadratic products, averaged around
 * a ring, are the **Reynolds stresses** `⟨w_r w_θ⟩`, `⟨w_r w_z⟩` — the radial fluxes of angular and
 * axial momentum that act on the background as an internal force. In the construction, two wave
 * families are chosen so that these two fluxes span a cone containing the stress the background
 * needs; here they are simply measured.
 */
export interface TransferRegion {
  /** Ring radius, or a radial interval `[r₁, r₂]` for an annulus. */
  r: number | [number, number];
  /** Height, or an interval `[z₁, z₂]`. Default 0. */
  z?: number | [number, number];
  /** Points around each ring. Default 64. */
  n?: number;
  /** Radial subdivisions when `r` is an interval. Default 8. */
  nr?: number;
  /** Axial subdivisions when `z` is an interval. Default 8. */
  nz?: number;
}

/** Options for {@link transfer}. */
export interface TransferOptions {
  /** Ring axis; normalized internally. Default `[0, 0, 1]`. */
  axis?: Vec3;
  center?: Vec3;
  /** Viscosity used for the dissipation term. Default 0.01. */
  nu?: number;
  /** Time at which both fields are sampled. Default 0. */
  t?: number;
}

/** The result of {@link transfer}. Every entry is a region mean weighted by `r` (the volume element). */
export interface TransferResult {
  /** Reynolds stresses in the ring frame: `⟨w_r w_θ⟩` (angular-momentum flux), `⟨w_r w_z⟩` (axial), `⟨w_r²⟩`. */
  stress: { rTheta: number; rZ: number; rr: number };
  /** `−⟨w_i w_j ∂_j U_i⟩` — positive when the layer extracts energy from the base's shear. */
  exchange: number;
  /** `ν⟨|∇w|²⟩` — always ≥ 0. */
  dissipation: number;
  /** `½⟨|w|²⟩`. */
  energy: number;
  /** `(exchange − dissipation)/(2·energy)`: the instantaneous exponential growth rate of the layer's energy. */
  growthRate: number;
  /** Number of sample points. */
  samples: number;
}

function perp(n: Vec3): Vec3 {
  const ax = Math.abs(n[0]), ay = Math.abs(n[1]), az = Math.abs(n[2]);
  const m: Vec3 = ax < ay ? (ax < az ? [1, 0, 0] : [0, 0, 1]) : ay < az ? [0, 1, 0] : [0, 0, 1];
  const d = m[0] * n[0] + m[1] * n[1] + m[2] * n[2];
  const p: Vec3 = [m[0] - d * n[0], m[1] - d * n[1], m[2] - d * n[2]];
  const l = Math.hypot(p[0], p[1], p[2]) || 1;
  return [p[0] / l, p[1] / l, p[2] / l];
}

/**
 * Measure the momentum transfer from `base` to `layer` over a ring or annulus around `axis`.
 *
 * ```js
 * const base = collapsingVortex({ h: 0.1, T: 2 });
 * const layer = ridePulses(base, { rings: pulseRings({ count: 12, r: [0.3, 0.6], seed: 3 }) });
 * transfer(base, layer, { r: [0.3, 0.6], z: [-0.2, 0.2] }, { t: 0.5, nu: 0.01 }).growthRate;
 * ```
 *
 * Both fields answer `sampleGrad` analytically, so nothing here is differenced; the only
 * approximation is the quadrature over the region.
 */
export function transfer(base: FlowField, layer: FlowField, region: TransferRegion, opts: TransferOptions = {}): TransferResult {
  const ax = opts.axis ?? [0, 0, 1];
  const an = Math.hypot(ax[0], ax[1], ax[2]) || 1;
  const n: Vec3 = [ax[0] / an, ax[1] / an, ax[2] / an];
  const e1 = perp(n);
  const e2: Vec3 = [n[1] * e1[2] - n[2] * e1[1], n[2] * e1[0] - n[0] * e1[2], n[0] * e1[1] - n[1] * e1[0]];
  const c = opts.center ?? [0, 0, 0];
  const nu = opts.nu ?? 0.01;
  const t = opts.t ?? 0;
  const nth = Math.max(4, region.n ?? 64);

  const span = (v: number | [number, number] | undefined, k: number, dflt: number): number[] => {
    if (v === undefined) return [dflt];
    if (typeof v === "number") return [v];
    const out: number[] = [];
    for (let i = 0; i < k; i++) out.push(v[0] + ((i + 0.5) / k) * (v[1] - v[0]));
    return out;
  };
  const rs = span(region.r, Math.max(1, region.nr ?? 8), 0);
  const zs = span(region.z, Math.max(1, region.nz ?? 8), 0);

  const gb: number[] = new Array(9).fill(0), gw: number[] = new Array(9).fill(0);
  let W = 0, sRT = 0, sRZ = 0, sRR = 0, sEx = 0, sDis = 0, sEn = 0, count = 0;
  for (const r of rs) for (const z of zs) {
    const wgt = Math.max(r, 1e-12);
    for (let i = 0; i < nth; i++) {
      const th = (2 * Math.PI * i) / nth, ct = Math.cos(th), st = Math.sin(th);
      const er: Vec3 = [ct * e1[0] + st * e2[0], ct * e1[1] + st * e2[1], ct * e1[2] + st * e2[2]];
      const ep: Vec3 = [-st * e1[0] + ct * e2[0], -st * e1[1] + ct * e2[1], -st * e1[2] + ct * e2[2]];
      const x = c[0] + r * er[0] + z * n[0], y = c[1] + r * er[1] + z * n[1], zz = c[2] + r * er[2] + z * n[2];
      const w = layer.sample(x, y, zz, t);
      base.sampleGrad(x, y, zz, gb, t);
      layer.sampleGrad(x, y, zz, gw, t);
      const wr = w[0] * er[0] + w[1] * er[1] + w[2] * er[2];
      const wt = w[0] * ep[0] + w[1] * ep[1] + w[2] * ep[2];
      const wz = w[0] * n[0] + w[1] * n[1] + w[2] * n[2];
      let ex = 0, dis = 0;
      for (let m = 0; m < 3; m++) for (let k = 0; k < 3; k++) {
        ex -= w[k] * w[m] * gb[3 * m + k]; // −w_k w_m ∂_m U_k
        dis += gw[3 * m + k] * gw[3 * m + k];
      }
      sRT += wgt * wr * wt; sRZ += wgt * wr * wz; sRR += wgt * wr * wr;
      sEx += wgt * ex; sDis += wgt * nu * dis;
      sEn += wgt * 0.5 * (w[0] * w[0] + w[1] * w[1] + w[2] * w[2]);
      W += wgt; count++;
    }
  }
  const inv = W > 0 ? 1 / W : 0;
  const energy = sEn * inv, exchange = sEx * inv, dissipation = sDis * inv;
  return {
    stress: { rTheta: sRT * inv, rZ: sRZ * inv, rr: sRR * inv },
    exchange,
    dissipation,
    energy,
    growthRate: energy > 0 ? (exchange - dissipation) / (2 * energy) : 0,
    samples: count,
  };
}
